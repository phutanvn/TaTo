//
//  MessageResponse.swift
//  CareShop
//
//  Created by Cupid on 10/28/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import Foundation

struct MessageResponse
{
    var errCode: Int?
    var message: String?
}
