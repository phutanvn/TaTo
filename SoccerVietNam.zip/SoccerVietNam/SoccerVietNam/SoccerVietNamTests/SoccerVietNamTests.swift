//
//  SoccerVietNamTests.swift
//  SoccerVietNamTests
//
//  Created by Cupid on 4/23/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import XCTest
@testable import SoccerVietNam

class SoccerVietNamTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        /*DataCenter.login(userName: "admin", passWord: "123456", domainName: "", completion:
            {
                user in
            }
        )*/
        
        /*DataCenter.getScaffoldByMatch(matchId: "77", statusList: ["1"], completion: {
            match in
            }
        )*/
        
        /*DataCenter.getGateByScaffold(matchId: "77", statusList: ["1"], id: "18", completion: {
            match in
            }
        )*/
        
        /*DataCenter.getStairByMatch(matchId: "77", statusList: ["1"], scaffoldId: "18", id: "15", completion: {
            match in
            }
        )*/
        
        //DataCenter.getRowByMatch(matchId: "77", statusList: ["1"], scaffoldId: "18", gateId: "15", id: "2", completion: {row in })
        DataCenter.getTicketByUser(fromDateStr: "", toDateStr: "", pageIndex: 1, pageSize: 10, completion: {row in })
        
        /*DataCenter.getAll(pageIndex: 1, pageSize: 10, domainName: "", completion: {
            match in
            }
        )*/
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
}
