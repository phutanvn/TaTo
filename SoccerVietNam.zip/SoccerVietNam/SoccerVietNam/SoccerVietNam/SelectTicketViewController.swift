//
//  SelectTicketViewController.swift
//  SoccerVietNam
//
//  Created by Cupid on 5/5/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import UIKit

class SelectTicketViewController: UIViewController {

    @IBOutlet weak var imgViewA2: UIImageView!
    @IBOutlet weak var imgViewA1: UIImageView!
    @IBOutlet weak var imgViewA3: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let goViewA1 = UITapGestureRecognizer(target: self, action: #selector(selectA1))
        self.imgViewA1.isUserInteractionEnabled = true
        self.imgViewA1.addGestureRecognizer(goViewA1)
        
        let goViewA2 = UITapGestureRecognizer(target: self, action: #selector(selectA2))
        self.imgViewA2.isUserInteractionEnabled = true
        self.imgViewA2.addGestureRecognizer(goViewA2)
        
        let goViewA3 = UITapGestureRecognizer(target: self, action: #selector(selectA3))
        self.imgViewA3.isUserInteractionEnabled = true
        self.imgViewA3.addGestureRecognizer(goViewA3)
    }
    
    @objc func selectA1()
    {
        DispatchQueue.main.async
            {
                let bookTicketVC = self.storyboard?.instantiateViewController(withIdentifier: "BookTicketViewController") as! BookTicketViewController
                
                self.tabBarController?.navigationController?.pushViewController(bookTicketVC, animated: true)
                //self.performSegue(withIdentifier: "goBookTicket", sender: nil)
        }
    }
    
    @objc func selectA2()
    {
        DispatchQueue.main.async
            {
                self.performSegue(withIdentifier: "goBookTicket", sender: nil)
        }
    }
    
    @objc func selectA3()
    {
        DispatchQueue.main.async
            {
                self.performSegue(withIdentifier: "goBookTicket", sender: nil)
        }
    }
    
    @IBAction func btnBackTouched(_ sender: Any) {
        self.dismiss(animated: true, completion:{}
        )
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
