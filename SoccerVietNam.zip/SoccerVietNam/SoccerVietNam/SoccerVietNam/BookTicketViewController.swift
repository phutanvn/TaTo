//
//  BookTicketViewController.swift
//  SoccerVietNam
//
//  Created by Cupid on 5/5/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import UIKit
import SwiftOverlays

class BookTicketViewController: UIViewController
{
    @IBOutlet weak var cbbGate: CustomDropDown!
    @IBOutlet weak var cbbStair: CustomDropDown!
    @IBOutlet weak var cbbRow: CustomDropDown!
    
    
    @IBOutlet weak var lblInfoMatch: UILabel!
    @IBOutlet weak var lblHours: UILabel!
    
    var lstGate = [GateInfo]()
    var lstStair = [StairInfo]()
    var lstRow = [RowInfo]()
    
    static var scraffold = ScaftInfo()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.getGateInfo()
        
        cbbGate.selectionAction = { [unowned self] (index: Int, item: String) in
            self.cbbGate.selectedIndex = index
            self.cbbGate.text = item
            
            self.getStairInfo(gateId: self.lstGate[index].id)
        }
        
        cbbStair.selectionAction = { [unowned self] (index: Int, item: String) in
            self.cbbStair.selectedIndex = index
            self.cbbStair.text = item
            
            self.getRowInfo(gateId: self.lstGate[self.cbbGate._selectedIndex].id, stairId: self.lstStair[index].id)
        }
        
        cbbRow.selectionAction = { [unowned self] (index: Int, item: String) in
            self.cbbRow.selectedIndex = index
            self.cbbRow.text = item
        }
    }

    func getGateInfo()
    {
        SwiftOverlays.showTextOverlay(self.view, text: "Đang tải dữ liệu...")
        DataCenter.getGateByScaffold(matchId: "77", statusList: ["1"], id: "18", completion:
            {gates in
                
                self.lstGate = gates!
                self.cbbGate.dataSource(self.lstGate.map({$0.name! }))
                SwiftOverlays.removeAllOverlaysFromView(self.view)
        })
    }
    
    func getStairInfo(gateId: String?)
    {
        SwiftOverlays.showTextOverlay(self.view, text: "Đang tải dữ liệu...")
        DataCenter.getStairByMatch(matchId: "77", statusList: ["1"], scaffoldId: "18", id: gateId, completion:
            {stairs in
                
                self.lstStair = stairs!
                self.cbbStair.dataSource(self.lstStair.map({$0.name! }))
                SwiftOverlays.removeAllOverlaysFromView(self.view)
        })
    }
    
    func getRowInfo(gateId: String?, stairId: String?)
    {
        SwiftOverlays.showTextOverlay(self.view, text: "Đang tải dữ liệu...")
        DataCenter.getRowByMatch(matchId: "77", statusList: ["1"], scaffoldId: "18", gateId: gateId, id: stairId, completion:
            {rows in
                
                self.lstRow = rows!
                self.cbbRow.dataSource(self.lstRow.map({$0.name! }))
                SwiftOverlays.removeAllOverlaysFromView(self.view)
        })
    }
    
    @IBAction func btnBookTicketTouched(_ sender: Any)
    {
        var ticket = Ticket()
        ticket.seasonId = "1"
        ticket.matchId = "77"
        ticket.code = "4324324234234001"
        ticket.type = "1"
        ticket.price = "35000"
        ticket.paymentStatus = "1"
        ticket.machineStatus = "1"
        ticket.gateId = "1"
        ticket.line = "1"
        ticket.position = "1"
        ticket.scaffoldId = "2"
        ticket.stairId = "2"
        ticket.numberOrder = "1"
        ticket.saleChannel = "2"
        
        var lstTicket = [Ticket]()
        lstTicket.append(ticket)
        
        SwiftOverlays.showTextOverlay(self.view, text: "Đang tải dữ liệu...")
        DataCenter.exportSellOnline(ticketList: lstTicket, completion:
            {rows in
                SwiftOverlays.removeAllOverlaysFromView(self.view)
        })
    }
    
    @IBAction func btnBackTouched(_ sender: Any) {
        self.dismiss(animated: true, completion: {}
        )
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
