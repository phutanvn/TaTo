//
//  MatchInfoDetail.swift
//  SoccerVietNam
//
//  Created by Cupid on 5/4/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import Foundation
struct MatchInfoDetail {
    var name: String?
    var foundationDate: String?
    var image: String?
    var address: String?
    var phone: String?
    var webSite: String?
    var status: String?
    var _id: String?
    var domainId: String?
    var idStr: String?
    var domainIdStr: String?
    
}
