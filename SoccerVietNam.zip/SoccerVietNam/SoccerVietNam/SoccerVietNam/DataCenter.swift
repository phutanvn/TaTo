//
//  DataCenter.swift
//  SoccerVietNam
//
//  Created by Cupid on 4/25/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON
import SwiftMessages

public class DataCenter
{
    init()
    {
        
    }
    
    static func login(userName : String?, passWord : String? , domainName : String?,
                      completion:@escaping(UserInfo?) -> Void)
    {
        Alamofire.request(
            URL(string: "http://bongdaviet.com.vn/api/user/login")!,
            method: .post,
            parameters: ["UserName": userName ?? "",
                         "Password": passWord ?? "",
                         "DomainName": domainName ?? ""
                         ],
            encoding: JSONEncoding.default,
            headers: [
                "content-type": "application/json",
                "AppKey": "1234567890abcdef123"
            ])
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                    completion(nil)
                    return
                }
                
                guard ((response.result.value as? [String: Any]) != nil) else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                    completion(nil)
                    return
                }
                
                let json = JSON(data: response.data!)
                print(json)
                if (json["ErrorCode"].stringValue != "000000")
                {
                    Utils.showAlert(title: "", body: json["ErrorMessage"].stringValue)
                    completion(nil)
                    return
                }
                
                var jsonResult = json["Data"]
                let jsonUser = jsonResult[0]
                
                let info = UserInfo(sessionId: jsonUser["SessionId"].stringValue, userType: jsonUser["UserType"].stringValue, userStatus: jsonUser["UserStatus"].stringValue, userName: userName, id: jsonUser["ID"].stringValue, domainName: jsonUser["DomainName"].stringValue)
                
                completion(info)
        }
    }
    
    /*static func register(username: String?, password: String?, email: String?, fullName: String?,gender: String?,birhDay:String?,domainName: String?,fbAccount: String?, completion: @escaping(MessageResponse?) -> Void)
    {
        Alamofire.request(
            URL(string: "http://bongdaviet.com.vn/api/user/register")!,
            method: .get,
            parameters: ["UserName": username ?? "",
                         "Password": password ?? "",
                         "Email": email ?? "",
                         "FullName": fullName ?? "",
                         "Gender": gender ?? "",
                         "Birthday": birhDay ?? "",
                         "DomainName": domainName ?? "",
                         "FbAccount": fbAccount ?? ""])
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                    completion(nil)
                    return
                }
                
                guard ((response.result.value as? [String: Any]) != nil) else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                    completion(nil)
                    return
                }
                
                let json = JSON(data: response.data!)
                
                if (json["ErrorCode"].stringValue != "000000")
                {
                    Utils.showAlert(title: "", body: json["ErrorMessage"].stringValue)
                    completion(nil)
                    return
                }
                
                let info = MessageResponse(errCode: json["ErrorCode"].stringValue, message: json["ErrorMessage"].stringValue)
                completion(info)
        }
    }
    
    static func logout(sessionId: String?, completion: @escaping(MessageResponse?) -> Void)
    {
        Alamofire.request(
            URL(string: "http://bongdaviet.com.vn/api/user/logout")!,
            method: .get,
            parameters: ["SessionId": sessionId ?? ""])
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                    completion(nil)
                    return
                }
                
                guard ((response.result.value as? [String: Any]) != nil) else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                    completion(nil)
                    return
                }
                
                let json = JSON(data: response.data!)
                
                if (json["ErrorCode"].stringValue != "000000")
                {
                    Utils.showAlert(title: "", body: json["ErrorMessage"].stringValue)
                    completion(nil)
                    return
                }
                
                let info = MessageResponse(errorCod: json["ErrorCode"].stringValue, message: json["ErrorMessage"].stringValue)
                completion(info)
        }
    }*/
    
    static func getAll(pageIndex: Int?, pageSize: Int?, domainName: String?, completion: @escaping([MatchInfo]?) -> Void)
    {
        Alamofire.request(
            URL(string: "http://bongdaviet.com.vn/api/match/getAll")!,
            method: .post,
            parameters: ["PageIndex": pageIndex ?? "",
                         "PageSize": pageSize ?? "",
                         "DomainName": domainName ?? ""],
            encoding: JSONEncoding.default,
            headers: [
                "content-type": "application/json",
                "AppKey": "1234567890abcdef123"
                ])
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                    completion(nil)
                    return
                }

                guard ((response.result.value as? [String: Any]) != nil) else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                    completion(nil)
                    return
                }

                let json = JSON(data: response.data!)
                print(json)
                if (json["ErrorCode"].stringValue != "000000")
                {
                    Utils.showAlert(title: "", body: json["ErrorMessage"].stringValue)
                    completion(nil)
                    return
                }

                let matchInfos = json["Data"].flatMap({ (matchInfo) -> MatchInfo? in
                    let category = matchInfo.1
                    
                    let jsonHost = category["Host"]
                    let jsonGuest = category["Guest"]
                    
                    let host = MatchInfoDetail(name: jsonHost["Name"].stringValue, foundationDate: jsonHost["FoundationDate"].stringValue, image: NSString.init(format: "http://bongdaviet.com.vn/%@", jsonHost["Image"].stringValue) as String, address: jsonHost["Address"].stringValue, phone: jsonHost["Phone"].stringValue, webSite: jsonHost["WebSite"].stringValue, status: jsonHost["Status"].stringValue, _id: jsonHost["_id"].stringValue, domainId: jsonHost["DomainId"].stringValue, idStr: jsonHost["IdStr"].stringValue, domainIdStr: jsonHost["DomainIdStr"].stringValue)
                    
                    let guest = MatchInfoDetail(name: jsonGuest["Name"].stringValue, foundationDate: jsonGuest["FoundationDate"].stringValue, image: NSString.init(format: "http://bongdaviet.com.vn/%@", jsonGuest["Image"].stringValue) as String, address: jsonGuest["Address"].stringValue, phone: jsonGuest["Phone"].stringValue, webSite: jsonGuest["WebSite"].stringValue, status: jsonGuest["Status"].stringValue, _id: jsonGuest["_id"].stringValue, domainId: jsonGuest["DomainId"].stringValue, idStr: jsonGuest["IdStr"].stringValue, domainIdStr: jsonGuest["DomainIdStr"].stringValue)
                    
                    return MatchInfo(name: category["Name"].stringValue, matchTime: category["MatchTime"].stringValue, matchTimeStr: category["MatchTimeStr"].stringValue, ogranizationUnit: category["OgranizationUnit"].stringValue, isDeleted: category["IsDeleted"].boolValue, place: category["Place"].stringValue, status: category["Status"].stringValue, description: category["Description"].stringValue, imageUrl: category["ImageUrl"].stringValue, textScore: category["TextScore"].stringValue, originalCode: category["OriginalCode"].stringValue, id: category["ID"].stringValue, _id: category["_id"].stringValue, domainId: category["DomainId"].stringValue, idStr: category["IdStr"].stringValue, domainIdStr: category["DomainIdStr"].stringValue, host: host, guest: guest)
                })
                completion(matchInfos)
        }
    }
    
    static func getScaffoldByMatch(matchId: String?, statusList: [String]?, completion: @escaping([ScaftInfo]?) -> Void)
    {
        Alamofire.request(
            URL(string: "http://bongdaviet.com.vn/api/match/GetScaffoldByMatch")!,
            method: .post,
            parameters: ["MatchId": matchId ?? "",
                         "StatusList": statusList ?? "" ],
            encoding: JSONEncoding.default,
            headers: [
                "content-type": "application/json",
                "AppKey": "1234567890abcdef123"
            ])
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                    completion(nil)
                    return
                }
                
                guard ((response.result.value as? [String: Any]) != nil) else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                    completion(nil)
                    return
                }
                
                let json = JSON(data: response.data!)
                
                if (json["ErrorCode"].stringValue != "000000")
                {
                    Utils.showAlert(title: "", body: json["ErrorMessage"].stringValue)
                    completion(nil)
                    return
                }
                
                let scraffolds = json["Data"].flatMap({ (scraffold) -> ScaftInfo? in
                    let category = scraffold.1
                     
                     /*let jsonHost = category["Host"]
                     let jsonGuest = category["Guest"]
                     
                     let host = MatchInfoDetail(name: jsonHost["Name"].stringValue, foundationDate: jsonHost["FoundationDate"].stringValue, image: NSString.init(format: "http://bongdaviet.com.vn/%@", jsonHost["Image"].stringValue) as String, address: jsonHost["Address"].stringValue, phone: jsonHost["Phone"].stringValue, webSite: jsonHost["WebSite"].stringValue, status: jsonHost["Status"].stringValue, _id: jsonHost["_id"].stringValue, domainId: jsonHost["DomainId"].stringValue, idStr: jsonHost["IdStr"].stringValue, domainIdStr: jsonHost["DomainIdStr"].stringValue)
                     
                     let guest = MatchInfoDetail(name: jsonGuest["Name"].stringValue, foundationDate: jsonGuest["FoundationDate"].stringValue, image: NSString.init(format: "http://bongdaviet.com.vn/%@", jsonGuest["Image"].stringValue) as String, address: jsonGuest["Address"].stringValue, phone: jsonGuest["Phone"].stringValue, webSite: jsonGuest["WebSite"].stringValue, status: jsonGuest["Status"].stringValue, _id: jsonGuest["_id"].stringValue, domainId: jsonGuest["DomainId"].stringValue, idStr: jsonGuest["IdStr"].stringValue, domainIdStr: jsonGuest["DomainIdStr"].stringValue)
                     
                     return MatchInfo(name: category["Name"].stringValue, matchTime: category["MatchTime"].stringValue, matchTimeStr: category["MatchTimeStr"].stringValue, ogranizationUnit: category["OgranizationUnit"].stringValue, isDeleted: category["IsDeleted"].boolValue, place: category["Place"].stringValue, status: category["Status"].stringValue, description: category["Description"].stringValue, imageUrl: category["ImageUrl"].stringValue, textScore: category["TextScore"].stringValue, originalCode: category["OriginalCode"].stringValue, id: category["ID"].stringValue, _id: category["_id"].stringValue, domainId: category["DomainId"].stringValue, idStr: category["IdStr"].stringValue, domainIdStr: category["DomainIdStr"].stringValue, host: host, guest: guest)*/
                    
                    return nil
                })
                completion(scraffolds)
        }
    }
    
    static func getGateByScaffold(matchId: String?, statusList: [String]?, id: String?, completion: @escaping([GateInfo]?) -> Void)
    {
        Alamofire.request(
            URL(string: "http://bongdaviet.com.vn/api/match/GetGateByScaffold")!,
            method: .post,
            parameters: ["MatchId": matchId ?? "",
                         "StatusList": statusList ?? "",
                         "ID": id ?? ""],
            encoding: JSONEncoding.default,
            headers: [
                "content-type": "application/json",
                "AppKey": "1234567890abcdef123"
            ])
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                    completion(nil)
                    return
                }
                
                guard ((response.result.value as? [String: Any]) != nil) else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                    completion(nil)
                    return
                }
                
                let json = JSON(data: response.data!)
                print(json)
                if (json["ErrorCode"].stringValue != "000000")
                {
                    Utils.showAlert(title: "", body: json["ErrorMessage"].stringValue)
                    completion(nil)
                    return
                }
                
                let gateInfos = json["Data"].flatMap({ (gateInfo) -> GateInfo? in
                    let gate = gateInfo.1
                    
                    return GateInfo(id: gate["ID"].stringValue, name: gate["Name"].stringValue, description: gate["Description"].stringValue, isDelete: gate["IsDelete"].boolValue, createdDate: gate["CreatedDate"].stringValue, createdBy: gate["CreatedBy"].stringValue, deletedBy: gate["DeletedBy"].stringValue, deletedDate: gate["DeletedDate"].stringValue, _id: gate["_id"].stringValue, domainId: gate["DomainId"].stringValue, idStr: gate["IdStr"].stringValue, domainIdStr: gate["DomainIdStr"].stringValue)
                })
                completion(gateInfos)
        }
    }
    
    static func getStairByMatch(matchId: String?, statusList: [String]?, scaffoldId: String?, id: String?, completion: @escaping([StairInfo]?) -> Void)
    {
        Alamofire.request(
            URL(string: "http://bongdaviet.com.vn/api/match/GetStairByMatch")!,
            method: .post,
            parameters: ["MatchId":matchId ?? "",
                         "StatusList":statusList ?? "",
                         "ScaffoldId":scaffoldId ?? "",
                         "ID":id ?? ""],
            encoding: JSONEncoding.default,
            headers: [
                "content-type": "application/json",
                "AppKey": "1234567890abcdef123"
            ])
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                    completion(nil)
                    return
                }
                
                guard ((response.result.value as? [String: Any]) != nil) else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                    completion(nil)
                    return
                }
                
                let json = JSON(data: response.data!)
                print(json)
                if (json["ErrorCode"].stringValue != "000000")
                {
                    Utils.showAlert(title: "", body: json["ErrorMessage"].stringValue)
                    completion(nil)
                    return
                }
                
                let stairInfos = json["Data"].flatMap({ (stairInfo) -> StairInfo? in
                    let stair = stairInfo.1
                    
                    return StairInfo(id: stair["ID"].stringValue, scaffoldId: stair["ScaffoldId"].stringValue, numRow: stair["NumRow"].stringValue, numSeat: stair["NumSeat"].stringValue, name: stair["Name"].stringValue, description: stair["Description"].stringValue, isDeleted: stair["IsDeleted"].boolValue, createdDate: stair["CreatedDate"].stringValue, createdBy: stair["CreatedBy"].stringValue, deletedBy: stair["DeletedBy"].stringValue, deletedDate: stair["DeletedDate"].stringValue, _id: stair["_id"].stringValue, domainId: stair["DomainId"].stringValue, idStr: stair["IdStr"].stringValue, domainIdStr: stair["DomainIdStr"].stringValue)
                })
                completion(stairInfos)
        }
    }
        
    static func getRowByMatch(matchId: String?, statusList: [String]?, scaffoldId: String?, gateId: String?, id: String?, completion: @escaping([RowInfo]?) -> Void)
        {
            Alamofire.request(
                URL(string: "http://bongdaviet.com.vn/api/match/GetRowByMatch")!,
                method: .post,
                parameters: ["MatchId":matchId ?? "",
                             "StatusList":statusList ?? "",
                             "ScaffoldId":scaffoldId ?? "",
                             "GateId":gateId ?? "",
                             "ID":id ?? ""],
                encoding: JSONEncoding.default,
                headers: [
                    "content-type": "application/json",
                    "AppKey": "1234567890abcdef123"
                ])
                .validate()
                .responseJSON { (response) -> Void in
                    guard response.result.isSuccess else
                    {
                        Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                        completion(nil)
                        return
                    }
                    
                    guard ((response.result.value as? [String: Any]) != nil) else
                    {
                        Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                        completion(nil)
                        return
                    }
                    
                    let json = JSON(data: response.data!)
                    print(json)
                    if (json["ErrorCode"].stringValue != "000000")
                    {
                        Utils.showAlert(title: "", body: json["ErrorMessage"].stringValue)
                        completion(nil)
                        return
                    }
                    
                    let rowInfos = json["Data"].flatMap({ (rowInfo) -> RowInfo? in
                        let row = rowInfo.1
                        
                        return RowInfo(name: row["Name"].stringValue, price: row["Price"].stringValue, line: row["Line"].stringValue)
                    })
                    completion(rowInfos)
            }
        }
    
    static func exportSellOnline(ticketList: [Ticket]?, completion: @escaping(MessageResponse?) -> Void)
    {
        Alamofire.request(
            URL(string: "http://bongdaviet.com.vn/api/ticket/ExportSellOnline")!,
            method: .post,
            parameters: ["TicketList": ticketList ?? ""],
            encoding: JSONEncoding.default,
            headers: [
                      "content-type": "application/json",
                      "AppKey": "1234567890abcdef123"
            ])
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                    completion(nil)
                    return
                }
                
                guard ((response.result.value as? [String: Any]) != nil) else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                    completion(nil)
                    return
                }
                
                let json = JSON(data: response.data!)
                
                if (json["ErrorCode"].stringValue != "000000")
                {
                    Utils.showAlert(title: "", body: json["ErrorMessage"].stringValue)
                    completion(nil)
                    return
                }
                
                let info = MessageResponse(errorCode: json["ErrorCode"].stringValue, description: json["ErrorMessage"].stringValue)
                completion(info)
        }
    }
    
    static func getTicketByUser(fromDateStr: String?, toDateStr: String?, pageIndex: Int?, pageSize: Int?, completion: @escaping([Ticket]?) -> Void)
    {
        Alamofire.request(
            URL(string: "http://bongdaviet.com.vn/api/ticket/GetTicketByUser")!,
            method: .post,
            parameters: ["FromDateStr": fromDateStr ?? "",
                         "ToDateStr": toDateStr ?? "",
                         "PageIndex": pageIndex ?? "",
                         "PageSize": pageSize ?? ""],
            encoding: JSONEncoding.default,
            headers: [
                "content-type": "application/json",
                "AppKey": "1234567890abcdef123",
                "SessionId": "57e0054a604f42cfaccc68f04a74d86c"
            ])
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                    completion(nil)
                    return
                }
                
                guard ((response.result.value as? [String: Any]) != nil) else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                    completion(nil)
                    return
                }
                
                let json = JSON(data: response.data!)
                print(json)
                if (json["ErrorCode"].stringValue != "000000")
                {
                    Utils.showAlert(title: "", body: json["ErrorMessage"].stringValue)
                    completion(nil)
                    return
                }
                
                let ticketInfos = json["Data"].flatMap({ (ticketInfo) -> Ticket? in
                    let ticket = ticketInfo.1
                    
                    let jsonMatchInfo = ticket["MatchInfo"]
                    let jsonHost = jsonMatchInfo["Host"]
                    let jsonGuest = jsonMatchInfo["Guest"]
                    
                    let host = MatchInfoDetail(name: jsonHost["Name"].stringValue, foundationDate: jsonHost["FoundationDate"].stringValue, image: NSString.init(format: "http://bongdaviet.com.vn/%@", jsonHost["Image"].stringValue) as String, address: jsonHost["Address"].stringValue, phone: jsonHost["Phone"].stringValue, webSite: jsonHost["WebSite"].stringValue, status: jsonHost["Status"].stringValue, _id: jsonHost["_id"].stringValue, domainId: jsonHost["DomainId"].stringValue, idStr: jsonHost["IdStr"].stringValue, domainIdStr: jsonHost["DomainIdStr"].stringValue)
                    
                    let guest = MatchInfoDetail(name: jsonGuest["Name"].stringValue, foundationDate: jsonGuest["FoundationDate"].stringValue, image: NSString.init(format: "http://bongdaviet.com.vn/%@", jsonGuest["Image"].stringValue) as String, address: jsonGuest["Address"].stringValue, phone: jsonGuest["Phone"].stringValue, webSite: jsonGuest["WebSite"].stringValue, status: jsonGuest["Status"].stringValue, _id: jsonGuest["_id"].stringValue, domainId: jsonGuest["DomainId"].stringValue, idStr: jsonGuest["IdStr"].stringValue, domainIdStr: jsonGuest["DomainIdStr"].stringValue)
                    
                    let matchInfo = MatchInfo(name: jsonMatchInfo["Name"].stringValue, matchTime: jsonMatchInfo["MatchTime"].stringValue, matchTimeStr: jsonMatchInfo["MatchTimeStr"].stringValue, ogranizationUnit: jsonMatchInfo["OgranizationUnit"].stringValue, isDeleted: jsonMatchInfo["IsDeleted"].boolValue, place: jsonMatchInfo["Place"].stringValue, status: jsonMatchInfo["Status"].stringValue, description: jsonMatchInfo["Description"].stringValue, imageUrl: jsonMatchInfo["ImageUrl"].stringValue, textScore: jsonMatchInfo["TextScore"].stringValue, originalCode: jsonMatchInfo["OriginalCode"].stringValue, id: jsonMatchInfo["ID"].stringValue, _id: jsonMatchInfo["_id"].stringValue, domainId: jsonMatchInfo["DomainId"].stringValue, idStr: jsonMatchInfo["IdStr"].stringValue, domainIdStr: jsonMatchInfo["DomainIdStr"].stringValue, host: host, guest: guest)
                    
                    return Ticket(footballMatchParam: ticket["FootballMatchParam"].stringValue, footballMatchParamStr: ticket["FootballMatchParamStr"].stringValue, scaffoldName: ticket["ScaffoldName"].stringValue, zoneCode: ticket["ZoneCode"].stringValue, scaffoldId: ticket["ScaffoldId"].stringValue, gateName: ticket["GateName"].stringValue, gateId: ticket["GateId"].stringValue, floor: ticket["Floor"].stringValue, stairName: ticket["StairName"].stringValue, stairId: ticket["StairId"].stringValue, line: ticket["Line"].stringValue, rowName: ticket["RowName"].stringValue, position: ticket["Position"].stringValue, barcode: ticket["Barcode"].stringValue, serial: ticket["Serial"].stringValue, status: ticket["Status"].stringValue, createdDateStr: ticket["CreatedDateStr"].stringValue, price: ticket["Price"].stringValue, footballMatchId: ticket["FootballMatchId"].stringValue, footballMachIdStr: ticket["FootballMachIdStr"].stringValue, matchInfo: matchInfo, ticketGenerated: ticket["TicketGenerated"].stringValue, ticketType: ticket["TicketType"].stringValue, matchName: ticket["MatchName"].stringValue, isValid: ticket["IsValid"].stringValue, ticketImportId: ticket["TicketImportId"].stringValue, type: ticket["Type"].stringValue, ticketTypeName: ticket["TicketTypeName"].stringValue, code: ticket["Code"].stringValue, matchId: ticket["MatchId"].stringValue, seasonId: ticket["SeasonId"].stringValue, seasonName: ticket["SeasonName"].stringValue, numberOrder: ticket["NumberOrder"].stringValue, paymentStatus: ticket["PaymentStatus"].stringValue, saleChannel: ticket["SaleChannel"].stringValue, paymentStatusName: ticket["PaymentStatusName"].stringValue, machineStatus: ticket["MachineStatus"].stringValue, machineStatusName: ticket["MachineStatusName"].stringValue, expiredHandleTime: ticket["ExpiredHandleTime"].stringValue, ownerName: ticket["OwnerName"].stringValue, ownerId: ticket["OwnerId"].stringValue, ownerIdStr: ticket["OwnerIdStr"].stringValue, id: ticket["ID"].stringValue, _id: ticket["_id"].stringValue, domainId: ticket["DomainId"].stringValue, idStr: ticket["IdStr"].stringValue, domainIdStr: ticket["DomainIdStr"].stringValue)
                })
                completion(ticketInfos)
        }
    }
    
    /*static func getDetail(sessionId: String?, code: String?, barCode: String?, idStr: String?, numberOrder: String?, completion: @escaping(Ticket?) -> Void)
    {
        Alamofire.request(
            URL(string: "http://bongdaviet.com.vn/api/ticket/GetDetail")!,
            method: .post,
            parameters: ["Code": code ?? "",
                         "BarCode": barCode ?? "",
                         "IdStr": idStr ?? "",
                         "NumberOrder": numberOrder ?? ""],
            encoding: JSONEncoding.default,
            headers: [
                "content-type": "application/json",
                "AppKey": "1234567890abcdef123",
                "SessionId": sessionId ?? ""
            ])
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                    completion(nil)
                    return
                }
                
                guard ((response.result.value as? [String: Any]) != nil) else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                    completion(nil)
                    return
                }
                
                let json = JSON(data: response.data!)
                print(json)
                if (json["ErrorCode"].stringValue != "000000")
                {
                    Utils.showAlert(title: "", body: json["ErrorMessage"].stringValue)
                    completion(nil)
                    return
                }
                
                let ticketInfos = json["Data"].flatMap({ (ticketInfo) -> Ticket? in
                    let ticket = ticketInfo.1
                    
                    let jsonMatchInfo = ticket["MatchInfo"]
                    let jsonHost = jsonMatchInfo["Host"]
                    let jsonGuest = jsonMatchInfo["Guest"]
                    
                    let host = MatchInfoDetail(name: jsonHost["Name"].stringValue, foundationDate: jsonHost["FoundationDate"].stringValue, image: NSString.init(format: "http://bongdaviet.com.vn/%@", jsonHost["Image"].stringValue) as String, address: jsonHost["Address"].stringValue, phone: jsonHost["Phone"].stringValue, webSite: jsonHost["WebSite"].stringValue, status: jsonHost["Status"].stringValue, _id: jsonHost["_id"].stringValue, domainId: jsonHost["DomainId"].stringValue, idStr: jsonHost["IdStr"].stringValue, domainIdStr: jsonHost["DomainIdStr"].stringValue)
                    
                    let guest = MatchInfoDetail(name: jsonGuest["Name"].stringValue, foundationDate: jsonGuest["FoundationDate"].stringValue, image: NSString.init(format: "http://bongdaviet.com.vn/%@", jsonGuest["Image"].stringValue) as String, address: jsonGuest["Address"].stringValue, phone: jsonGuest["Phone"].stringValue, webSite: jsonGuest["WebSite"].stringValue, status: jsonGuest["Status"].stringValue, _id: jsonGuest["_id"].stringValue, domainId: jsonGuest["DomainId"].stringValue, idStr: jsonGuest["IdStr"].stringValue, domainIdStr: jsonGuest["DomainIdStr"].stringValue)
                    
                    let matchInfo = MatchInfo(name: jsonMatchInfo["Name"].stringValue, matchTime: jsonMatchInfo["MatchTime"].stringValue, matchTimeStr: jsonMatchInfo["MatchTimeStr"].stringValue, ogranizationUnit: jsonMatchInfo["OgranizationUnit"].stringValue, isDeleted: jsonMatchInfo["IsDeleted"].boolValue, place: jsonMatchInfo["Place"].stringValue, status: jsonMatchInfo["Status"].stringValue, description: jsonMatchInfo["Description"].stringValue, imageUrl: jsonMatchInfo["ImageUrl"].stringValue, textScore: jsonMatchInfo["TextScore"].stringValue, originalCode: jsonMatchInfo["OriginalCode"].stringValue, id: jsonMatchInfo["ID"].stringValue, _id: jsonMatchInfo["_id"].stringValue, domainId: jsonMatchInfo["DomainId"].stringValue, idStr: jsonMatchInfo["IdStr"].stringValue, domainIdStr: jsonMatchInfo["DomainIdStr"].stringValue, host: host, guest: guest)
                    
                    return Ticket(footballMatchParam: ticket["FootballMatchParam"].stringValue, footballMatchParamStr: ticket["FootballMatchParamStr"].stringValue, scaffoldName: ticket["ScaffoldName"].stringValue, zoneCode: ticket["ZoneCode"].stringValue, scaffoldId: ticket["ScaffoldId"].stringValue, gateName: ticket["GateName"].stringValue, gateId: ticket["GateId"].stringValue, floor: ticket["Floor"].stringValue, stairName: ticket["StairName"].stringValue, stairId: ticket["StairId"].stringValue, line: ticket["Line"].stringValue, rowName: ticket["RowName"].stringValue, position: ticket["Position"].stringValue, barcode: ticket["Barcode"].stringValue, serial: ticket["Serial"].stringValue, status: ticket["Status"].stringValue, createdDateStr: ticket["CreatedDateStr"].stringValue, price: ticket["Price"].stringValue, footballMatchId: ticket["FootballMatchId"].stringValue, footballMachIdStr: ticket["FootballMachIdStr"].stringValue, matchInfo: matchInfo, ticketGenerated: ticket["TicketGenerated"].stringValue, ticketType: ticket["TicketType"].stringValue, matchName: ticket["MatchName"].stringValue, isValid: ticket["IsValid"].stringValue, ticketImportId: ticket["TicketImportId"].stringValue, type: ticket["Type"].stringValue, ticketTypeName: ticket["TicketTypeName"].stringValue, code: ticket["Code"].stringValue, matchId: ticket["MatchId"].stringValue, seasonId: ticket["SeasonId"].stringValue, seasonName: ticket["SeasonName"].stringValue, numberOrder: ticket["NumberOrder"].stringValue, paymentStatus: ticket["PaymentStatus"].stringValue, saleChannel: ticket["SaleChannel"].stringValue, paymentStatusName: ticket["PaymentStatusName"].stringValue, machineStatus: ticket["MachineStatus"].stringValue, machineStatusName: ticket["MachineStatusName"].stringValue, expiredHandleTime: ticket["ExpiredHandleTime"].stringValue, ownerName: ticket["OwnerName"].stringValue, ownerId: ticket["OwnerId"].stringValue, ownerIdStr: ticket["OwnerIdStr"].stringValue, id: ticket["ID"].stringValue, _id: ticket["_id"].stringValue, domainId: ticket["DomainId"].stringValue, idStr: ticket["IdStr"].stringValue, domainIdStr: ticket["DomainIdStr"].stringValue)
                })
                completion(ticketInfos)
        }
    }*/
}

