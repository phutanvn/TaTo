//
//  HomeViewController.swift
//  SoccerVietNam
//
//  Created by Cupid on 5/5/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import UIKit
import SwiftOverlays

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    @IBOutlet weak var tblMatches: UITableView!
    
    var lstMatches = [MatchInfo]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view        
        self.tblMatches.delegate = self
        self.tblMatches.dataSource = self
        getListMatches()
    }

    func getListMatches()
    {
        SwiftOverlays.showTextOverlay(self.tblMatches, text: "Đang tải dữ liệu...")
        DataCenter.getAll(pageIndex: 1, pageSize: 100, domainName: "", completion:
            {matches in
                
                if (matches != nil)
                {
                    self.lstMatches = matches!
                    self.tblMatches.reloadData()
                }
                SwiftOverlays.removeAllOverlaysFromView(self.tblMatches)
        })
    }
    /* TanDP - TableViewDelegate */
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.lstMatches.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 160
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
    {
        return 0.01
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MatchTableViewCell", for: indexPath) as! MatchTableViewCell
        let match = self.lstMatches[indexPath.row]
        
        cell.lblHostName.text = match.host?.name
        cell.lblGuestName.text = match.guest?.name
        
        let imgDataHost = NSData.init(contentsOf: URL.init(string: (match.host?.image)!)!)
        if (imgDataHost != nil)
        {
            cell.imgViewHostLogo.image = UIImage.init(data: imgDataHost! as Data)
        }
        
        let imgDataGuest = NSData.init(contentsOf: URL.init(string: (match.host?.image)!)!)
        if (imgDataGuest != nil)
        {
            cell.imgViewGuestLogo.image = UIImage.init(data: imgDataGuest! as Data)
        }
        
        cell.btnSelectTicket.addTarget(self, action: #selector(selectTicket), for: .touchUpInside)
        return cell
    }
    
    @objc func selectTicket()
    {
        DispatchQueue.main.async
        {
            let selectTicketVC = self.storyboard?.instantiateViewController(withIdentifier: "SelectTicketViewController") as! SelectTicketViewController
            
            self.navigationController?.pushViewController(selectTicketVC, animated: true)
            //self.performSegue(withIdentifier: "goSelectTicket", sender: self)
            //self.tabBarController?.navigationController?.performSegue(withIdentifier: "goSelectTicket", sender: self)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        /*if (tableView.tag == 0)
        {
            let newsDetailViewController = self.storyboard?.instantiateViewController(withIdentifier: "NewsDetailViewController") as! NewsDetailViewController
            newsDetailViewController.news = self.lstNews[indexPath.row]
            self.revealViewController().present(newsDetailViewController, animated: true)
        }*/
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
