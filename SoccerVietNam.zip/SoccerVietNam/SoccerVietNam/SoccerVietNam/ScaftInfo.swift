//
//  ScaftInfo.swift
//  SoccerVietNam
//
//  Created by Cupid on 5/3/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import Foundation
struct ScaftInfo {
    var zoneCode: String?
    var zoneName : String?
    var mappingCode : String?
    var id : String?
    var name: String?
    var description : String?
    var isDeleted : Bool?
    var _id : String?
    var domainId : String?
    var idStr : String?
    var domainIdStr : String?
}
