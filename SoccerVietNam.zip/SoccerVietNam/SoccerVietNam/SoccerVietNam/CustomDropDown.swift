import UIKit
import DropDown

class CustomDropDown: ImageTextField, UITextFieldDelegate{

    var dropdown : DropDown!
    var _selectedIndex : Int = 0
    var _selectionAction: SelectionClosure?

    public var selectedIndex : Int{
        get{
            return self._selectedIndex
        }
        set{
            self._selectedIndex = newValue
            dropdown.selectRow(at: newValue)
            text = dropdown.dataSource[newValue]
        }
    }

    public var selectionAction: SelectionClosure?{
        get{
            if _selectionAction == nil {
                return self.dropdown.selectionAction
            }else{
                return _selectionAction
            }
        }
        set{
            _selectionAction = newValue
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupDropDown()
    }

    class func initDefaultAppearance(){
        let appearance = DropDown.appearance()

        appearance.cellHeight = 45
        appearance.backgroundColor = UIColor(white: 1, alpha: 1)
        appearance.selectionBackgroundColor = UIColor(red: 0.6494, green: 0.8155, blue: 1.0, alpha: 0.35)
        appearance.separatorColor = UIColor(white: 0.7, alpha: 0.0)
        appearance.cornerRadius = 10
        appearance.shadowColor = UIColor(white: 0.6, alpha: 1)
        appearance.shadowOpacity = 0.9
        appearance.shadowRadius = 25
        appearance.animationduration = 0.25
        appearance.textColor = .darkGray
    }

    private func setupDropDown() {
        if dropdown == nil{
            fieldImage = #imageLiteral(resourceName: "ic_arrow_drop_down")
            dropdown = DropDown()
            dropdown.direction = .any
            dropdown.anchorView = self

            dropdown.topOffset = CGPoint(x: 0, y:-((dropdown.anchorView?.plainView.bounds.height)! + 3))
            dropdown.bottomOffset = CGPoint(x: 0, y:((dropdown.anchorView?.plainView.bounds.height)! + 3))
        }

        dropdown.selectionAction = { [unowned self] (index: Int, item: String) in
            self.selectedIndex = index
            self.text = item

            if self._selectionAction != nil {
                self._selectionAction!(index, item)
            }
        }

        self.delegate = self
    }

    public func dataSource(_ dataSource : [String]){
        dropdown.dataSource = dataSource
    }

    func showDropdown(){
        if dropdown.dataSource.count > 0 {
            dropdown.show()
        }
    }

    //MARK: Delegate
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        showDropdown()
        return false
    }
}
