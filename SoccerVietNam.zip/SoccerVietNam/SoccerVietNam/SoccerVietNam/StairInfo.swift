//
//  StairInfo.swift
//  SoccerVietNam
//
//  Created by Cupid on 5/4/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import Foundation
struct StairInfo {
    var id : String?
    var scaffoldId: String?
    var numRow: String?
    var numSeat: String?
    var name: String?
    var description: String?
    var isDeleted: Bool?
    var createdDate: String?
    var createdBy: String?
    var deletedBy: String?
    var deletedDate: String?
    var _id: String?
    var domainId: String?
    var idStr: String?
    var domainIdStr: String?
    
}
