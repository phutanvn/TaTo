//
//  Profile.swift
//  SoccerVietNam
//
//  Created by Cupid on 5/4/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import Foundation
struct Profile {
   
    var fullName: String?
    var phone: String?
    var address: String?
    var gender: String?
    var facebookAccount: String?
    var website: String?
    var birthday: String?
    var birthdayStr: String?
    var province: String?
    var country: String?
    var workingPlace: String?
    var avatarUrl: String?
    var signature: String?
    var activateKey: String?
    var activateId: String?
    var resetPasswordKey: String?
    var avatarImage: String?
    var avatarImageId:String?
    var email: String?
    var _id: String?
//    "DomainId": "000000000000000000000000",
//    "IdStr": "000000000000000000000000",
//    "DomainIdStr": "000000000000000000000000"
    
    
}
