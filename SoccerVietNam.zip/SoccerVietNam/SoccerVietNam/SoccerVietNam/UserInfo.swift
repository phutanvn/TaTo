//
//  UserInfo.swift
//  SoccerVietNam
//
//  Created by Cupid on 4/27/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import Foundation
struct UserInfo {
    var sessionId: String?
    var userType: String?
    var userStatus: String?
    var userName: String?
    var id:String?
    var domainName: String?
}
