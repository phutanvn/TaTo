//
//  MatchInfo.swift
//  SoccerVietNam
//
//  Created by Cupid on 5/2/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import Foundation
struct MatchInfo {
    var name : String?
    var matchTime: String?
    var matchTimeStr: String?
    var ogranizationUnit : String?
    var isDeleted : Bool?
    var place: String?
    var status : String?
    var description :String?
    var imageUrl : String?
    var textScore: String?
    var originalCode : String?
    var id : String?
    var _id: String?
    var domainId : String?
    var idStr: String?
    var domainIdStr: String?
    var host : MatchInfoDetail?
    var guest : MatchInfoDetail?
    
}

