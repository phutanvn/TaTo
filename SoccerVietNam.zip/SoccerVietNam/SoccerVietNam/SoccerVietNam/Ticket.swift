//
//  Ticket.swift
//  SoccerVietNam
//
//  Created by Cupid on 5/3/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import Foundation
struct Ticket {

    var footballMatchParam: String?
    var footballMatchParamStr: String?
    var scaffoldName: String?
    var zoneCode : String?
    var scaffoldId : String?
    var gateName: String?
    var gateId: String?
    var floor: String?
    var stairName: String?
    var stairId: String?
    var line: String?
    var rowName: String?
    var position: String?
    var barcode: String?
    var serial: String?
    var status: String?
    
    var createdDateStr: String?
    var price: String?
    var footballMatchId: String?
    var footballMachIdStr:String?
    var matchInfo : MatchInfo?
   
    var ticketGenerated: String?
    var ticketType: String?
    var matchName: String?
    var isValid: String?
    var ticketImportId: String?
    var type: String?
    var ticketTypeName: String?
    var code: String?
    var matchId: String?
    var seasonId: String?
    var seasonName: String?
    var numberOrder: String?
    var paymentStatus: String?
    var saleChannel: String?
    var paymentStatusName: String?
    var machineStatus: String?
    var machineStatusName: String?
    var expiredHandleTime : String?
    var ownerName: String?
    var ownerId: String?
    var ownerIdStr: String?
    var id: String?
    var _id: String?
    var domainId: String?
    var idStr: String?
    var domainIdStr: String?
    }

