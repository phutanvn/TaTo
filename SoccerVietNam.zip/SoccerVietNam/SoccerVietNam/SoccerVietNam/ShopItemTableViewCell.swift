//
//  ShopItemTableViewCell.swift
//  SoccerVietNam
//
//  Created by Cupid on 5/6/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import UIKit

class ShopItemTableViewCell: UITableViewCell {

    @IBOutlet weak var btnDetailLeft: UIButton!
    @IBOutlet weak var btnDetailRight: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
