//
//  RowInfo.swift
//  SoccerVietNam
//
//  Created by Cupid on 5/6/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import Foundation
struct RowInfo {
    var name: String?
    var price: String?
    var line: String?
}
