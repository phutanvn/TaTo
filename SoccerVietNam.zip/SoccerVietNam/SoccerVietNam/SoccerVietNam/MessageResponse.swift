//
//  MessageResponse.swift
//  SoccerVietNam
//
//  Created by Cupid on 4/27/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import Foundation
struct MessageResponse {
    var errorCode: String?
    var description :String?
}
