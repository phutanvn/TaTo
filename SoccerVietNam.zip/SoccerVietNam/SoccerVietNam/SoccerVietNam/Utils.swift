//
//  Utils.swift
//  CareShop
//
//  Created by Cupid on 10/28/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import Foundation
import SwiftMessages

public class Utils
{
    init()
    {
        
    }
    
    static func showAlert(title: String?, body: String?)
    {
        let view = MessageView.viewFromNib(layout: .MessageView)
        view.configureTheme(.warning)
        view.configureDropShadow()
        view.button?.isHidden = true
        
        let iconText = ["🤔", "😳", "🙄", "😶"].sm_random()!
        view.configureContent(title: title!, body: body!, iconText: iconText)
        
        SwiftMessages.show(view: view)
    }
}

