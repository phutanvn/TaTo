//
//  MatchTableViewCell.swift
//  SoccerVietNam
//
//  Created by Cupid on 5/5/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import UIKit

class MatchTableViewCell: UITableViewCell {
    
    @IBOutlet weak var viewCell: UIView!
    {
        didSet
        {
            viewCell.layer.cornerRadius = 10
            viewCell.layer.borderWidth = 1
            viewCell.layer.borderColor = UIColor.groupTableViewBackground.cgColor
        }
    }
    @IBOutlet weak var imgViewHostLogo: UIImageView!
    @IBOutlet weak var imgViewGuestLogo: UIImageView!
    @IBOutlet weak var lblHostName: UILabel!
    @IBOutlet weak var lblGuestName: UILabel!
    @IBOutlet weak var lblMatchTime: UILabel!
    @IBOutlet weak var lblMatchDate: UILabel!
    @IBOutlet weak var btnSelectTicket: UIButton!
    {
        didSet
        {
            btnSelectTicket.layer.cornerRadius = 5
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
