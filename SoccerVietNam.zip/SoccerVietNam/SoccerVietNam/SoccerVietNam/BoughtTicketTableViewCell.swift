//
//  BoughtTicketTableViewCell.swift
//  SoccerVietNam
//
//  Created by Cupid on 5/6/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import UIKit

class BoughtTicketTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imgViewHostLogo: UIImageView!
    @IBOutlet weak var imgViewGuestLogo: UIImageView!
    @IBOutlet weak var lblHostName: UILabel!
    @IBOutlet weak var lblGuestName: UILabel!
    @IBOutlet weak var lblMatchTime: UILabel!
    @IBOutlet weak var lblMatchDate: UILabel!
    @IBOutlet weak var btnViewicket: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
