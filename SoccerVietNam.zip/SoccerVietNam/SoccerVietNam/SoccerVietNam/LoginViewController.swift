//
//  LoginViewController.swift
//  SoccerVietNam
//
//  Created by Cupid on 4/24/18.
//  Copyright © 2018 Jdisoft. All rights reserved.
//

import UIKit
import SwiftOverlays

class LoginViewController: UIViewController {
    @IBOutlet weak var viewHolder: UIView!
    @IBOutlet weak var viewUserName: UIView!
        {
        didSet
        {
            viewUserName.layer.cornerRadius = 10
            viewUserName.layer.borderWidth = 1
            viewUserName.layer.borderColor = UIColor.init(red: 153/255, green: 165/255, blue: 255/255, alpha: 1.0).cgColor
        }
    }
    
    @IBOutlet weak var viewPassword: UIView!
        {
        didSet
        {
            viewPassword.layer.cornerRadius = 10
            viewPassword.layer.borderWidth = 1
            viewPassword.layer.borderColor = UIColor.init(red: 153/255, green: 165/255, blue: 255/255, alpha: 1.0).cgColor
        }
    }
    
    @IBOutlet weak var btnLogin: UIButton!
        {
        didSet
        {
            btnLogin.layer.cornerRadius = 10
        }
    }
    
    @IBOutlet weak var btnRegister: UIButton!
        {
        didSet
        {
            btnRegister.layer.cornerRadius = 10
        }
    }
    
    @IBOutlet weak var iconUserName: UIImageView!
        {
        didSet
        {
            iconUserName.clipsToBounds = true
            iconUserName.layer.cornerRadius = 8
        }
    }
    @IBOutlet weak var iconPassword: UIImageView!
        {
        didSet
        {
            iconPassword.clipsToBounds = true
            iconPassword.layer.cornerRadius = 8
        }
    }
    
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnLoginTouched(_ sender: Any)
    {
        if (self.txtUserName.text?.isEmpty)!
        {
            Utils.showAlert(title: "", body: "Bạn chưa nhập tài khoản")
            return
        }
        
        if (self.txtPassword.text?.isEmpty)!
        {
            Utils.showAlert(title: "", body: "Bạn chưa nhập mật khẩu")
            return
        }
        
        SwiftOverlays.showTextOverlay(self.view, text: "Đang đăng nhập...")
        DataCenter.login(userName: self.txtUserName.text, passWord: self.txtPassword.text, domainName: "", completion: {user in
            
            SwiftOverlays.removeAllBlockingOverlays()
            if (user != nil)
            {
                //Session.userInfo = user
                DispatchQueue.main.async
                    {
                        self.performSegue(withIdentifier: "goHome", sender: nil)
                }
            }
        })    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
