//
//  HomePageViewController.swift
//  CareShop
//
//  Created by Vtsoft2 on 10/17/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit
import SwiftOverlays

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    @IBOutlet weak var btnMenu: UIButton!
    @IBOutlet weak var tblHome: UITableView!
    @IBOutlet weak var viewTopBar: UIView!        
    
    var lstProduct = [Product]()
    var lstService = [Product]()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.navigationController?.navigationItem.titleView = viewTopBar
        
        if revealViewController() != nil
        {
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
            btnMenu.addTarget(revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:)), for: UIControlEvents.touchDown)
        }
        
        self.tblHome.dataSource = self
        self.tblHome.delegate = self
        
        self.initData()
    }

    func initData()
    {
        //SwiftOverlays.showBlockingWaitOverlay()
        DataCenter.getActiveProduct(userName: Session.userInfo?.userName, password: Session.userInfo?.password, categoryId: 1, completion:
            {product in
                
                if (product != nil)
                {
                    if ((product?.count)! <= 5)
                    {
                        self.lstProduct = product!
                        self.lstService = product!
                    }
                    else
                    {
                        self.lstProduct.removeAll()
                        self.lstService.removeAll()
                        
                        for var i in 0..<5
                        {
                            let prd = product?[i]
                            self.lstProduct.append(prd!)
                            self.lstService.append(prd!)
                        }
                    }
                    
                    self.tblHome.reloadData()
                }
                
                //SwiftOverlays.removeAllBlockingOverlays()
            })
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        
    }
    
    /* TanDP - TableViewDelegate */
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 5
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        switch section
        {
        case 0:
            return 1
        case 1:
            return 2
        case 2:
            return 2
        case 3:
            return self.lstProduct.count + 2
        case 4:
            return self.lstService.count + 2
        default:
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if indexPath.section == 0
        {
            return 280
        }
        else if indexPath.section == 1
        {
            if indexPath.row == 0
            {
                return 60
            }
            else
            {
                return 150
            }
        }
        else if indexPath.section == 2
        {
            if indexPath.row == 0
            {
                return 60
            }
            else
            {
                return 150
            }
        }
        else if indexPath.section == 3 || indexPath.section == 4
        {
            return 60
        }
        else
        {
            return 100
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if (indexPath.section == 0)
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "CustommerTableViewCell", for: indexPath) as! CustommerTableViewCell
            
            cell.lblDisplayName.text = Session.userInfo?.displayName?.uppercased()
            cell.lblPhoneNumber.text = Session.userInfo?.phone
            let imgData = Data(base64Encoded: (Session.userInfo?.imageSmall)!)            
            if (imgData != nil)
            {
                cell.imgAvatar.image = UIImage.init(data: imgData!)
            }

            return cell
        }
        else if (indexPath.section == 1)
        {
            if (indexPath.row == 0)
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "SectionHeaderTableViewCell", for: indexPath) as! SectionHeaderTableViewCell
                cell.lblSectionTitle.text = "HFC PRIVILEGE"
                
                return cell
            }
            else
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "CustomerLevelTableViewCell", for: indexPath) as! CustomerLevelTableViewCell
                
                return cell
            }
        }
        else if (indexPath.section == 2)
        {
            if (indexPath.row == 0)
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "SectionHeaderTableViewCell", for: indexPath) as! SectionHeaderTableViewCell
                cell.lblSectionTitle.text = "TIÊU DÙNG"
                
                return cell
            }
            else
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "ChartTableViewCell", for: indexPath) as! ChartTableViewCell
                
                return cell
            }
        }
        else if (indexPath.section == 3)
        {
            if (indexPath.row == 0)
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "SectionHeaderTableViewCell", for: indexPath) as! SectionHeaderTableViewCell
                
                cell.lblSectionTitle.text = "KHUYẾN MẠI"
                
                return cell
            }
            else if (indexPath.row > 0 && indexPath.row < self.lstProduct.count + 1)
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "ProductTableViewCell", for: indexPath) as! ProductTableViewCell
                
                let product = self.lstProduct[indexPath.row-1]
                cell.lblProductName.text = product.displayName
                cell.lblPrice.text = product.lstPrice
                
                let imgData = Data(base64Encoded: (product.image)!)
                if (imgData != nil)
                {
                    cell.imgProduct.image = UIImage.init(data: imgData!)
                }
                
                return cell
            }
            else
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "ViewMoreTableViewCell", for: indexPath) as! ViewMoreTableViewCell                
                return cell
            }
        }
        else if (indexPath.section == 4)
        {
            if (indexPath.row == 0)
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "SectionHeaderTableViewCell", for: indexPath) as! SectionHeaderTableViewCell
                
                cell.lblSectionTitle.text = "DỊCH VỤ"
                
                return cell
            }
            else if (indexPath.row > 0 && indexPath.row < self.lstService.count + 1)
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "ProductTableViewCell", for: indexPath) as! ProductTableViewCell
                
                let product = self.lstService[indexPath.row-1]
                cell.lblProductName.text = product.displayName
                cell.lblPrice.text = product.lstPrice
                
                let imgData = Data(base64Encoded: (product.image)!)
                if (imgData != nil)
                {
                    cell.imgProduct.image = UIImage.init(data: imgData!)
                }
                
                return cell
            }
            else
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "ViewMoreTableViewCell", for: indexPath) as! ViewMoreTableViewCell
                return cell
            }
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "CustommerTableViewCell", for: indexPath) as! CustommerTableViewCell
            
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if (indexPath.section == 3 && (indexPath.row == 0 || indexPath.row >= self.lstProduct.count + 1))
        {
            Session.selectedProductType = 0
            
            let tabBarController = revealViewController().frontViewController as! UITabBarController
            
            tabBarController.selectedIndex = 1
            revealViewController().pushFrontViewController(tabBarController,animated:true)
        }
        else if (indexPath.section == 4 && (indexPath.row == 0 || indexPath.row >= self.lstService.count + 1))
        {
            Session.selectedProductType = 1
            
            let tabBarController = revealViewController().frontViewController as! UITabBarController
            
            tabBarController.selectedIndex = 1
            revealViewController().pushFrontViewController(tabBarController,animated:true)
        }
        else if (indexPath.section == 2 && indexPath.row == 0)
        {
            DispatchQueue.main.async
                {
                self.performSegue(withIdentifier: "goTransaction", sender: nil)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath)
    {
        if (indexPath.section != 0)
        {
        let cornerRadius: CGFloat = 10
        cell.backgroundColor = .clear
        
        let layer = CAShapeLayer()
        let pathRef = CGMutablePath()
        let bounds = cell.bounds.insetBy(dx: 10, dy: 0)
        var addLine = false
        
        if indexPath.row == 0 && indexPath.row == tableView.numberOfRows(inSection: indexPath.section) - 1 {
            pathRef.__addRoundedRect(transform: nil, rect: bounds, cornerWidth: cornerRadius, cornerHeight: cornerRadius)
        } else if indexPath.row == 0 {
            pathRef.move(to: .init(x: bounds.minX, y: bounds.maxY))
            pathRef.addArc(tangent1End: .init(x: bounds.minX, y: bounds.minY), tangent2End: .init(x: bounds.midX, y: bounds.minY), radius: cornerRadius)
            pathRef.addArc(tangent1End: .init(x: bounds.maxX, y: bounds.minY), tangent2End: .init(x: bounds.maxX, y: bounds.midY), radius: cornerRadius)
            pathRef.addLine(to: .init(x: bounds.maxX, y: bounds.maxY))
            addLine = true
        } else if indexPath.row == tableView.numberOfRows(inSection: indexPath.section) - 1 {
            pathRef.move(to: .init(x: bounds.minX, y: bounds.minY))
            pathRef.addArc(tangent1End: .init(x: bounds.minX, y: bounds.maxY), tangent2End: .init(x: bounds.midX, y: bounds.maxY), radius: cornerRadius)
            pathRef.addArc(tangent1End: .init(x: bounds.maxX, y: bounds.maxY), tangent2End: .init(x: bounds.maxX, y: bounds.midY), radius: cornerRadius)
            pathRef.addLine(to: .init(x: bounds.maxX, y: bounds.minY))
        } else {
            pathRef.addRect(bounds)
            addLine = true
        }
        
        layer.path = pathRef
        layer.fillColor = UIColor(white: 1, alpha: 0.8).cgColor
        
        if (addLine == true) {
            let lineLayer = CALayer()
            let lineHeight = 1.0 / UIScreen.main.scale
            lineLayer.frame = CGRect(x: bounds.minX + 10, y: bounds.size.height - lineHeight, width: bounds.size.width - 10, height: lineHeight)
            lineLayer.backgroundColor = tableView.separatorColor?.cgColor
            layer.addSublayer(lineLayer)
        }
        
        let testView = UIView(frame: bounds)
        testView.layer.insertSublayer(layer, at: 0)
        testView.backgroundColor = .clear
        cell.backgroundView = testView
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView)
    {
        /*if scrollView == self.tblHome
        {
            let contentOffset = scrollView.contentOffset.y
            
            if (contentOffset >= 0 && contentOffset <= 100)
            {
                //self.viewTopBar.backgroundColor = UIColor.init(colorLiteralRed: 240/255, green: 116/255, blue: 48/255, alpha: Float(contentOffset*(10/6)/100))
                self.viewTopBar.backgroundColor = UIColor.init(colorLiteralRed: 49/255, green: 186/255, blue: 253/255, alpha: Float(contentOffset*(10/6)/100))
            }
        }*/
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 10
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView?
    {
        let footerView = UIView.init(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 10))
        footerView.backgroundColor = UIColor.groupTableViewBackground
        
        return footerView
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
