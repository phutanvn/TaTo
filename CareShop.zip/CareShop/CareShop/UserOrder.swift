//
//  UserOrder.swift
//  CareShop
//
//  Created by thinhhq1 on 10/31/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit

struct UserOrder
{
    var id: String?
    var displayName: String?
    var dateOrder: String?
    var amountTotal: String?
    var amountTax: String?
    var amountUntaxed: String?
}

