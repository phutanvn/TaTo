//
//  ProductViewController.swift
//  CareShop
//
//  Created by Vtsoft2 on 10/18/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit
import SwiftOverlays

class ProductViewController: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    @IBOutlet weak var tblProduct: UITableView!
    @IBOutlet weak var tblService: UITableView!
    @IBOutlet weak var segmentType: UISegmentedControl!
    
    var lstProduct = [Product]()
    var lstService = [Product]()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.tblProduct.tag = 0
        self.tblProduct.dataSource = self
        self.tblProduct.delegate = self
        
        self.tblService.tag = 1
        self.tblService.dataSource = self
        self.tblService.delegate = self
        
        self.getListProduct()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getListProduct()
    {
        SwiftOverlays.showBlockingWaitOverlay()
        DataCenter.getActiveProduct(userName: Session.userInfo?.userName, password: Session.userInfo?.password, categoryId: -1, completion:
            {products in
                
                if (products != nil)
                {
                    self.lstProduct = products!
                    self.tblProduct.reloadData()
                }
                SwiftOverlays.removeAllBlockingOverlays()
        })
    }
    
    func getListService()
    {
        SwiftOverlays.showBlockingWaitOverlay()
        DataCenter.getActiveProduct(userName: Session.userInfo?.userName, password: Session.userInfo?.password, categoryId: -1, completion:
            {products in
                
                if (products != nil)
                {
                    self.lstService = products!
                    self.tblService.reloadData()
                }
                SwiftOverlays.removeAllBlockingOverlays()
        })
    }
    
    @IBAction func segmentTypeChange(_ sender: Any)
    {
        switch self.segmentType.selectedSegmentIndex {
        case 0:
            if (self.lstProduct.count == 0)
            {
                self.getListProduct()
            }
            self.tblProduct.isHidden = false
            self.tblService.isHidden = true
        case 1:
            if (self.lstService.count == 0)
            {
                self.getListService()
            }
            self.tblProduct.isHidden = true
            self.tblService.isHidden = false
        default:
            break
        }
    }
    
    /* TanDP - TableViewDelegate */
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if tableView.tag == 0
        {
            return self.lstProduct.count
        }
        else
        {
            return self.lstService.count
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 60
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if (tableView.tag == 0)
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ProductTableViewCell", for: indexPath) as! ProductTableViewCell
            
            let product = self.lstProduct[indexPath.row]
            cell.lblProductName.text = product.displayName
            cell.lblPrice.text = product.lstPrice
            
            return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ProductTableViewCell", for: indexPath) as! ProductTableViewCell
            
            let product = self.lstService[indexPath.row]
            cell.lblProductName.text = product.displayName
            cell.lblPrice.text = product.lstPrice
            
            return cell
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
