//
//  TransactionTableViewCell.swift
//  CareShop
//
//  Created by Cupid on 11/2/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit

class TransactionTableViewCell: UITableViewCell {
    @IBOutlet weak var lblOrderNumber: UILabel!

    @IBOutlet weak var lblOrderDate: UILabel!
    
    @IBOutlet weak var lblTotalAmount: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
