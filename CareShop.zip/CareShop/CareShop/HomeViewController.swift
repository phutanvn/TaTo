//
//  HomePageViewController.swift
//  CareShop
//
//  Created by Vtsoft2 on 10/17/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit
import SwiftOverlays
import Charts

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, ChartViewDelegate
{
    @IBOutlet weak var btnMenu: UIButton!
    @IBOutlet weak var tblHome: UITableView!
    @IBOutlet weak var viewTopBar: UIView!        
    
    var lstProduct = [Product]()
    var lstService = [Product]()
    
    let months = ["T01", "T02", "T03", "T04", "T05", "T06", "T07", "T08", "T09", "T10"]
    let unitsSold = [20.0, 4.0, 6.0, 3.0, 12.0, 16.0, 4.0, 18.0, 2.0, 4.0]
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.navigationController?.navigationItem.titleView = viewTopBar
        
        if revealViewController() != nil
        {
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
            btnMenu.addTarget(revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:)), for: UIControlEvents.touchDown)
        }
        
        self.tblHome.dataSource = self
        self.tblHome.delegate = self
        
        self.initData()
    }

    func initData()
    {
        //SwiftOverlays.showBlockingWaitOverlay()
        DataCenter.getActiveProduct(userName: Session.userInfo?.userName, password: Session.userInfo?.password, categoryId: 1, completion:
            {product in
                
                if (product != nil)
                {
                    self.lstProduct = product!
                    self.lstService = product!
                    
                    self.tblHome.reloadData()
                }
                
                //SwiftOverlays.removeAllBlockingOverlays()
            })
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        
    }
    
    /* TanDP - TableViewDelegate */
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 5
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        switch section
        {
        case 0:
            return 1
        case 1:
            return 2
        case 2:
            return 2
        case 3:
            return self.lstProduct.count + 2
        case 4:
            return self.lstService.count + 2
        default:
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if indexPath.section == 0
        {
            return 280
        }
        else if indexPath.section == 1
        {
            if indexPath.row == 0
            {
                return 60
            }
            else
            {
                return 150
            }
        }
        else if indexPath.section == 2
        {
            if indexPath.row == 0
            {
                return 60
            }
            else
            {
                return 250
            }
        }
        else if indexPath.section == 3 || indexPath.section == 4
        {
            return 60
        }
        else
        {
            return 100
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if (indexPath.section == 0)
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "CustommerTableViewCell", for: indexPath) as! CustommerTableViewCell
            
            cell.lblDisplayName.text = Session.userInfo?.displayName?.uppercased()
            cell.lblPhoneNumber.text = Session.userInfo?.phone
            let imgData = Data(base64Encoded: (Session.userInfo?.imageSmall)!)            
            if (imgData != nil)
            {
                cell.imgAvatar.image = UIImage.init(data: imgData!)
            }

            return cell
        }
        else if (indexPath.section == 1)
        {
            if (indexPath.row == 0)
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "SectionHeaderTableViewCell", for: indexPath) as! SectionHeaderTableViewCell
                cell.lblSectionTitle.text = "HFC PRIVILEGE"
                
                return cell
            }
            else
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "CustomerLevelTableViewCell", for: indexPath) as! CustomerLevelTableViewCell
                
                let goExchangeGiftRecognizer = UITapGestureRecognizer(target: self, action: #selector(goExchangeGift))
                cell.lblLoyaltyPoint.isUserInteractionEnabled = true
                cell.lblLoyaltyPoint.addGestureRecognizer(goExchangeGiftRecognizer )
                
                return cell
            }
        }
        else if (indexPath.section == 2)
        {
            if (indexPath.row == 0)
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "SectionHeaderTableViewCell", for: indexPath) as! SectionHeaderTableViewCell
                cell.lblSectionTitle.text = "TIÊU DÙNG"
                
                return cell
            }
            else
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "ChartTableViewCell", for: indexPath) as! ChartTableViewCell
                self.setChart(barChartView: cell.chartTransaction, dataPoints: months, values: unitsSold)
                
                return cell
            }
        }
        else if (indexPath.section == 3)
        {
            if (indexPath.row == 0)
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "SectionHeaderTableViewCell", for: indexPath) as! SectionHeaderTableViewCell
                
                cell.lblSectionTitle.text = "KHUYẾN MẠI"
                
                return cell
            }
            else if (indexPath.row > 0 && indexPath.row < self.lstProduct.count + 1)
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "ProductTableViewCell", for: indexPath) as! ProductTableViewCell
                
                let product = self.lstProduct[indexPath.row-1]
                cell.lblProductName.text = product.displayName
                cell.lblPrice.text = product.lstPrice
                
                let imgData = Data(base64Encoded: (product.image)!)
                if (imgData != nil)
                {
                    cell.imgProduct.image = UIImage.init(data: imgData!)
                }
                
                return cell
            }
            else
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "ViewMoreTableViewCell", for: indexPath) as! ViewMoreTableViewCell                
                return cell
            }
        }
        else if (indexPath.section == 4)
        {
            if (indexPath.row == 0)
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "SectionHeaderTableViewCell", for: indexPath) as! SectionHeaderTableViewCell
                
                cell.lblSectionTitle.text = "DỊCH VỤ"
                
                return cell
            }
            else if (indexPath.row > 0 && indexPath.row < self.lstService.count + 1)
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "ProductTableViewCell", for: indexPath) as! ProductTableViewCell
                
                let product = self.lstService[indexPath.row-1]
                cell.lblProductName.text = product.displayName
                cell.lblPrice.text = product.lstPrice
                
                let imgData = Data(base64Encoded: (product.image)!)
                if (imgData != nil)
                {
                    cell.imgProduct.image = UIImage.init(data: imgData!)
                }
                
                return cell
            }
            else
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "ViewMoreTableViewCell", for: indexPath) as! ViewMoreTableViewCell
                return cell
            }
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "CustommerTableViewCell", for: indexPath) as! CustommerTableViewCell
            
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if (indexPath.section == 3 && (indexPath.row == 0 || indexPath.row >= self.lstProduct.count + 1))
        {
            Session.selectedProductType = 0
            
            let tabBarController = revealViewController().frontViewController as! UITabBarController
            
            tabBarController.selectedIndex = 1
            revealViewController().pushFrontViewController(tabBarController,animated:true)
        }
        else if (indexPath.section == 4 && (indexPath.row == 0 || indexPath.row >= self.lstService.count + 1))
        {
            Session.selectedProductType = 1
            
            let tabBarController = revealViewController().frontViewController as! UITabBarController
            
            tabBarController.selectedIndex = 1
            revealViewController().pushFrontViewController(tabBarController,animated:true)
        }
        else if (indexPath.section == 2 && indexPath.row == 0)
        {
            DispatchQueue.main.async
                {
                self.performSegue(withIdentifier: "goTransaction", sender: nil)
            }
        }
    }
    
    func goExchangeGift()
    {
        DispatchQueue.main.async
            {
                self.performSegue(withIdentifier: "goExchangeGift", sender: nil)
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath)
    {
        if (indexPath.section != 0)
        {
        let cornerRadius: CGFloat = 10
        cell.backgroundColor = .clear
        
        let layer = CAShapeLayer()
        let pathRef = CGMutablePath()
        let bounds = cell.bounds.insetBy(dx: 10, dy: 0)
        var addLine = false
        
        if indexPath.row == 0 && indexPath.row == tableView.numberOfRows(inSection: indexPath.section) - 1 {
            pathRef.__addRoundedRect(transform: nil, rect: bounds, cornerWidth: cornerRadius, cornerHeight: cornerRadius)
        } else if indexPath.row == 0 {
            pathRef.move(to: .init(x: bounds.minX, y: bounds.maxY))
            pathRef.addArc(tangent1End: .init(x: bounds.minX, y: bounds.minY), tangent2End: .init(x: bounds.midX, y: bounds.minY), radius: cornerRadius)
            pathRef.addArc(tangent1End: .init(x: bounds.maxX, y: bounds.minY), tangent2End: .init(x: bounds.maxX, y: bounds.midY), radius: cornerRadius)
            pathRef.addLine(to: .init(x: bounds.maxX, y: bounds.maxY))
            addLine = true
        } else if indexPath.row == tableView.numberOfRows(inSection: indexPath.section) - 1 {
            pathRef.move(to: .init(x: bounds.minX, y: bounds.minY))
            pathRef.addArc(tangent1End: .init(x: bounds.minX, y: bounds.maxY), tangent2End: .init(x: bounds.midX, y: bounds.maxY), radius: cornerRadius)
            pathRef.addArc(tangent1End: .init(x: bounds.maxX, y: bounds.maxY), tangent2End: .init(x: bounds.maxX, y: bounds.midY), radius: cornerRadius)
            pathRef.addLine(to: .init(x: bounds.maxX, y: bounds.minY))
        } else {
            pathRef.addRect(bounds)
            addLine = true
        }
        
        layer.path = pathRef
        layer.fillColor = UIColor(white: 1, alpha: 0.8).cgColor
        
        if (addLine == true) {
            let lineLayer = CALayer()
            let lineHeight = 1.0 / UIScreen.main.scale
            lineLayer.frame = CGRect(x: bounds.minX + 10, y: bounds.size.height - lineHeight, width: bounds.size.width - 10, height: lineHeight)
            lineLayer.backgroundColor = tableView.separatorColor?.cgColor
            layer.addSublayer(lineLayer)
        }
        
        let testView = UIView(frame: bounds)
        testView.layer.insertSublayer(layer, at: 0)
        testView.backgroundColor = .clear
        cell.backgroundView = testView
        }
    }
    
    func setChart(barChartView: BarChartView, dataPoints: [String], values: [Double])
    {
        barChartView.noDataText = "You need to provide data for the chart."
        barChartView.leftAxis.drawAxisLineEnabled = false
        barChartView.leftAxis.drawGridLinesEnabled = false
        barChartView.leftAxis.drawLabelsEnabled = false
        barChartView.rightAxis.drawAxisLineEnabled = false
        barChartView.rightAxis.drawGridLinesEnabled = false
        barChartView.rightAxis.drawLabelsEnabled = false
        barChartView.xAxis.drawAxisLineEnabled = false
        barChartView.xAxis.drawGridLinesEnabled = false
        barChartView.xAxis.drawLabelsEnabled = false
        
        var dataEntries: [BarChartDataEntry] = []
        
        for i in 0..<dataPoints.count
        {
            let dataEntry = BarChartDataEntry.init(x: Double(i), yValues: [values[i]])
            dataEntries.append(dataEntry)
        }
        
        let chartDataSet = BarChartDataSet.init(values: dataEntries, label: "Thống kê 10 giao dịch gần nhất")
        chartDataSet.colors = ChartColorTemplates.material() //[self.viewTopBar.backgroundColor!]
        chartDataSet.values = dataEntries
        chartDataSet.valueFont = UIFont.init(name: "AvenirNextCondensed-Regular", size: 13.0)!
        
        var dataSets = [ChartDataSet]()
        dataSets.append(chartDataSet)
        
        let chartData = BarChartData.init(dataSets: dataSets)
        barChartView.data = chartData
        barChartView.chartDescription?.text = ""
        
        barChartView.xAxis.labelPosition = .bottom
        barChartView.animate(xAxisDuration: 0.0, yAxisDuration: 0.0, easingOption: .easeInBounce)
    }
    
    func chartValueSelected(chartView: ChartViewBase, entry: ChartDataEntry, dataSetIndex: Int, highlight: Highlight)
    {
        
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView)
    {
        /*if scrollView == self.tblHome
        {
            let contentOffset = scrollView.contentOffset.y
            
            if (contentOffset >= 0 && contentOffset <= 100)
            {
                //self.viewTopBar.backgroundColor = UIColor.init(colorLiteralRed: 240/255, green: 116/255, blue: 48/255, alpha: Float(contentOffset*(10/6)/100))
                self.viewTopBar.backgroundColor = UIColor.init(colorLiteralRed: 49/255, green: 186/255, blue: 253/255, alpha: Float(contentOffset*(10/6)/100))
            }
        }*/
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 10
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView?
    {
        let footerView = UIView.init(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 10))
        footerView.backgroundColor = UIColor.groupTableViewBackground
        
        return footerView
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
