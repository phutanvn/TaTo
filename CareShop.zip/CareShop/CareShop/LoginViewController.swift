//
//  LoginViewController.swift
//  CareShop
//
//  Created by Vtsoft2 on 10/17/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import SwiftOverlays
import IHKeyboardAvoiding

class LoginViewController: UIViewController
{
    @IBOutlet weak var viewHolder: UIView!
    @IBOutlet weak var viewUserName: UIView!
        {
            didSet
            {
                viewUserName.layer.cornerRadius = 25
                viewUserName.layer.borderWidth = 1
                viewUserName.layer.borderColor = UIColor.white.cgColor
            }
        }
    
    @IBOutlet weak var viewPassword: UIView!
        {
            didSet
            {
                viewPassword.layer.cornerRadius = 25
                viewPassword.layer.borderWidth = 1
                viewPassword.layer.borderColor = UIColor.white.cgColor
            }
        }
    
    @IBOutlet weak var btnLogin: UIButton!
        {
            didSet
            {
                btnLogin.layer.cornerRadius = 25
            }
        }
    
    @IBOutlet weak var btnRegister: UIButton!
        {
            didSet
            {
                btnRegister.layer.cornerRadius = 25
            }
        }
    
    @IBOutlet weak var iconUserName: UIImageView!
        {
            didSet
            {
                iconUserName.clipsToBounds = true
                iconUserName.layer.cornerRadius = 15
            }
        }
    @IBOutlet weak var iconPassword: UIImageView!
        {
            didSet
            {
                iconPassword.clipsToBounds = true
                iconPassword.layer.cornerRadius = 15
            }
        }
    
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        KeyboardAvoiding.avoidingView = self.viewHolder
        hideKeyboardWhenTappedAround(false)
    }

    @IBAction func btnLoginTouched(_ sender: Any)
    {
        /*DataCenter.getListProductCategory(userName: "tienmh@gmail.com", password: "12345678a@", parentCategory: 1, completion: {productCategory in
            print(productCategory ?? "")
        })*/
        
        if (self.txtUserName.text?.isEmpty)!
        {
            Utils.showAlert(title: "", body: "Bạn chưa nhập tài khoản")
            return
        }
        
        if (self.txtPassword.text?.isEmpty)!
        {
            Utils.showAlert(title: "", body: "Bạn chưa nhập mật khẩu")
            return
        }
        
        SwiftOverlays.showBlockingWaitOverlay()
        DataCenter.getUserInfo(userName: self.txtUserName.text, password: self.txtPassword.text, utm_source: "zalo", utm_medium: "zalo", utm_campaign: "zalo", zarsrc: "1303", completion: {user in
            
            SwiftOverlays.removeAllBlockingOverlays()
            if (user != nil)
            {
                Session.userInfo = user                
                self.performSegue(withIdentifier: "goHome", sender: nil)
            }
        })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
