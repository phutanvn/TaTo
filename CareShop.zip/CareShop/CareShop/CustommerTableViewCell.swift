//
//  CustommerTableViewCell.swift
//  CareShop
//
//  Created by Vtsoft2 on 10/18/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit

class CustommerTableViewCell: UITableViewCell
{
    @IBOutlet weak var lblDisplayName: UILabel!
    @IBOutlet weak var lblPhoneNumber: UILabel!
    @IBOutlet weak var lblLevel: UILabel!
    
    @IBOutlet weak var imgAvatar: UIImageView!
    {
        didSet
        {
            imgAvatar.layer.masksToBounds = true
            imgAvatar.layer.cornerRadius = 40
            imgAvatar.layer.borderWidth = 5
            imgAvatar.layer.borderColor = UIColor.white.cgColor
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
