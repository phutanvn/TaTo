//
//  ChartTableViewCell.swift
//  CareShop
//
//  Created by Cupid on 10/29/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit
import Charts

class ChartTableViewCell: UITableViewCell
{

    @IBOutlet weak var chartTransaction: BarChartView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
