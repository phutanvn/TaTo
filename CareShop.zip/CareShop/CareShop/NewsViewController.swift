//
//  NewsViewController.swift
//  CareShop
//
//  Created by thinhhq1 on 10/31/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit
import SwiftOverlays

class NewsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    @IBOutlet weak var tblNews: UITableView!
    @IBOutlet weak var tblPromotion: UITableView!
    @IBOutlet weak var segmentType: UISegmentedControl!
    
    var lstNews = [News]()
    var lstPromotion = [News]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.tblNews.tag = 0
        self.tblNews.dataSource = self
        self.tblNews.delegate = self
        
        self.tblPromotion.tag = 1
        self.tblPromotion.dataSource = self
        self.tblPromotion.delegate = self
        
        self.getListInformation()
    }
    
    func getListInformation()
    {
        SwiftOverlays.showTextOverlay(self.tblNews, text: "Đang tải dữ liệu...")
        DataCenter.getListInformation(userName: Session.userInfo?.userName, password: Session.userInfo?.password, blogId: "1", completion:
            {news in
                
                if (news != nil)
                {
                    self.lstNews = news!
                    self.tblNews.reloadData()
                }
                SwiftOverlays.removeAllOverlaysFromView(self.tblNews)
        })
    }
    
    func getListPromotion()
    {
        SwiftOverlays.showTextOverlay(self.tblPromotion, text: "Đang tải dữ liệu...")
        DataCenter.getListInformation(userName: Session.userInfo?.userName, password: Session.userInfo?.password, blogId: "2", completion:
            {news in
                
                if (news != nil)
                {
                    self.lstPromotion = news!
                    self.tblPromotion.reloadData()
                }
                SwiftOverlays.removeAllOverlaysFromView(self.tblPromotion)
        })
    }


    /* TanDP - TableViewDelegate */
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if tableView.tag == 0
        {
            return self.lstNews.count
        }
        else
        {
            return self.lstPromotion.count
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 120
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
    {
        return 0.01
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if (tableView.tag == 0)
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "NewsTableViewCell", for: indexPath) as! NewsTableViewCell
            
            let news = self.lstNews[indexPath.row]
            cell.lblTitle.text = news.name
            
            return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "NewsTableViewCell", for: indexPath) as! NewsTableViewCell
            
            //let news = self.lstPromotion[indexPath.row]
            //cell.lblTitle.text = news.name ?? ""
            
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if (tableView.tag == 0)
        {
            let newsDetailViewController = self.storyboard?.instantiateViewController(withIdentifier: "NewsDetailViewController") as! NewsDetailViewController
            newsDetailViewController.news = self.lstNews[indexPath.row]
            self.revealViewController().present(newsDetailViewController, animated: true)
        }
    }
    
    @IBAction func segmentTypeChange(_ sender: Any)
    {
        switch self.segmentType.selectedSegmentIndex {
        case 0:
            if (self.lstNews.count == 0)
            {
                self.getListInformation()
            }
            self.tblNews.isHidden = false
            self.tblPromotion.isHidden = true
        case 1:
            if (self.lstPromotion.count == 0)
            {
                self.getListPromotion()
            }
            self.tblNews.isHidden = true
            self.tblPromotion.isHidden = false
        default:
            break
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
