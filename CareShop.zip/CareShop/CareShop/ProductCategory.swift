//
//  ProductCategory.swift
//  CareShop
//
//  Created by Cupid on 10/28/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import Foundation

struct ProductCategory
{
    var lastUpdate: String?
    var createDate: String?
    var displayName: String?
    var id: String?
    var name: String?
    var parentLeft: String?
    var parentRight: String?
    var productCount: String?
    var propertyCostMethod: String?
    var propertyValuation: String?
    var type: String?
    var writeDate: String?
}
