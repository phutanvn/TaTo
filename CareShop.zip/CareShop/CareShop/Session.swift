//
//  Session.swift
//  CareShop
//
//  Created by Cupid on 10/28/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import Foundation

public class Session
{
    static var userInfo: UserInfo?
    static var selectedProductType: Int! = 0
    
    init()
    {
        
    }
}
