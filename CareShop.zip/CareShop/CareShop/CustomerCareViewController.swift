//
//  CustomerCareViewController.swift
//  CareShop
//
//  Created by Vtsoft2 on 10/18/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit

class CustomerCareViewController: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    @IBOutlet weak var tblCustomerCare: UITableView!
    
    var lstMenu = [MenuItem]()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        lstMenu.append(MenuItem(id: 1, title: "Chat với chăm sóc khách hàng", icon: UIImage.init(named: "icon-Chat")!))
        lstMenu.append(MenuItem(id: 2, title: "Tổng đài chăm sóc khách hàng", icon: UIImage.init(named: "icon-CustomerService")!))
        lstMenu.append(MenuItem(id: 3, title: "Câu hỏi thường gặp", icon: UIImage.init(named: "icon-QA")!))
        lstMenu.append(MenuItem(id: 4, title: "Gửi email góp ý", icon: UIImage.init(named: "icon-Email")!))
        
        self.tblCustomerCare.dataSource = self
        self.tblCustomerCare.delegate = self
    }
    
    /* TanDP - TableViewDelegate */
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.lstMenu.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 80
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomerCareTableViewCell", for: indexPath) as! CustomerCareTableViewCell
        
        let menu = lstMenu[indexPath.row]
        
        cell.imgIcon.image = menu.icon
        cell.lblChannelTitle.text = menu.title
        
        return cell
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
