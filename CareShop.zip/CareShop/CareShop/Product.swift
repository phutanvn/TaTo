//
//  Product.swift
//  CareShop
//
//  Created by Cupid on 10/29/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import Foundation

struct Product
{
    var categId: String?
    var displayName: String?
    var id: String?
    var image: String?
    var listPrice: String?
    var lstPrice: String?
}
