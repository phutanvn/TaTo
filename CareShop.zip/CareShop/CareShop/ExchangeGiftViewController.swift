//
//  ExchangeGiftViewController.swift
//  CareShop
//
//  Created by Cupid on 11/6/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit
import SCLAlertView

class ExchangeGiftViewController: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    @IBOutlet weak var tblGift: UITableView!
    
    
    var lstGift = [Gift]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.lstGift.append(Gift(name: "Điện thoại iPhone 6S 32GB", price: "16.000", image: UIImage.init(named: "image-iPhone"), quantity: 1))
        self.lstGift.append(Gift(name: "Điện thoại iPhone 6S 64GB", price: "19.000", image: UIImage.init(named: "image-iPhone"), quantity: 1))
        self.lstGift.append(Gift(name: "Voucher Spa 500.000 VND", price: "500", image: UIImage.init(named: "image-Voucher500"), quantity: 10))
        self.lstGift.append(Gift(name: "Voucher Spa 200.000 VND", price: "200", image: UIImage.init(named: "image-Voucher200"), quantity: 10))
        self.lstGift.append(Gift(name: "Thẻ Viettel 200.000 VND", price: "200", image: UIImage.init(named: "image-ViettelCard"), quantity: 10))
        
        self.tblGift.dataSource = self
        self.tblGift.delegate = self
    }
    
    /* TanDP - TableViewDelegate */
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.lstGift.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 125
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
    {
        return 0.01
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ExchangeGiftTableViewCell", for: indexPath) as! ExchangeGiftTableViewCell
        
        let gift = self.lstGift[indexPath.row]
        
        cell.imgGift.image = gift.image
        cell.lblName.text = gift.name
        cell.lblPrice.text = String.init(format: "%@ coin", gift.price!)
        //cell.lblQuantity.text = gift.quantity
        
        cell.btnExchange.tag = indexPath.row
        cell.btnExchange.addTarget(self, action: #selector(exchangeGift(_:)), for: .touchUpInside)
        return cell
    }

    func exchangeGift(_ sender: UIButton)
    {
        let gift = self.lstGift[sender.tag]
        
        let appearance = SCLAlertView.SCLAppearance(
            showCloseButton: false
        )
        let alertView = SCLAlertView(appearance: appearance)
        alertView.showSuccess("Congratulation!", subTitle: String.init(format: "Chúc mừng bạn đã nhận được phần quà là sản phẩm %@", gift.name!), duration: 5)
    }
    
    @IBAction func btnCloseTouched(_ sender: Any)
    {
        self.dismiss(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
