//
//  ViewController.swift
//  CareShop
//
//  Created by Cupid on 10/28/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit
@IBDesignable
extension UIViewController
{
    /**
     - Description: hide keyboard when tapped around View
     */
    func hideKeyboardWhenTappedAround(_ cancelsTouchesInView: Bool = false) {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.dismissKeyboard))
        tap.cancelsTouchesInView = cancelsTouchesInView
        view.addGestureRecognizer(tap)
    }
    
    /**
     - Description: Dismiss keyboard
     */
    func dismissKeyboard() {
        view.endEditing(true)
    }
}
