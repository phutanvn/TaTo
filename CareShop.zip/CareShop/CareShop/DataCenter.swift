//
//  DataCenter.swift
//  CareShop
//
//  Created by thinhhq1 on 10/23/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON
import SwiftMessages

public class DataCenter
{
    init()
    {
        
    }
    
    static func getUserInfo(userName: String?, password: String?, utm_source: String?, utm_medium: String?, utm_campaign: String?, zarsrc: String?, completion: @escaping(UserInfo?) -> Void)
    {
        Alamofire.request(
            URL(string: "http://104.199.251.67:8888/MyCareWS/getUserInfo")!,
            method: .get,
            parameters: ["password": password ?? "",
                         "userName": userName ?? "",
                         "utm_source": utm_source ?? "",
                         "utm_medium": utm_medium ?? "",
                         "utm_campaign": utm_campaign ?? "",
                         "zarsrc": zarsrc ?? ""])
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                    completion(nil)
                    return
                }
                
                guard ((response.result.value as? [String: Any]) != nil) else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                    completion(nil)
                    return
                }
                
                let json = JSON(data: response.data!)
                
                if (json["errCode"].intValue != 0)
                {
                    Utils.showAlert(title: "", body: json["message"].stringValue)
                    completion(nil)
                    return
                }
                
                var jsonResult = json["result"][1]
                
                let info = UserInfo(userName: userName, password: password, displayName: jsonResult["displayName"].stringValue, email: jsonResult["email"].stringValue, id: jsonResult["id"].intValue, contactAddress: jsonResult["contactAddress"].stringValue, imageSmall: jsonResult["imageSmall"].stringValue.replacingOccurrences(of: "\n", with: ""), phone: jsonResult["phone"].stringValue)
                
                completion(info)
        }
    }
    
    static func registerUser(username: String?, password: String?, companyId: String?, customerName: String?, completion: @escaping(MessageResponse?) -> Void)
    {
        Alamofire.request(
            URL(string: "http://104.199.251.67:8888/MyCareWS/registerUser")!,
            method: .get,
            parameters: ["username": username ?? "",
                         "password": password ?? "",
                         "companyId": companyId ?? "",
                         "customerName": customerName ?? ""])
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                    completion(nil)
                    return
                }
                
                guard ((response.result.value as? [String: Any]) != nil) else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                    completion(nil)
                    return
                }
                
                let json = JSON(data: response.data!)
                
                if (json["errCode"].intValue != 0)
                {
                    Utils.showAlert(title: "", body: json["message"].stringValue)
                    completion(nil)
                    return
                }
                
                let info = MessageResponse(errCode: json["errCode"].intValue, message: json["message"].stringValue)
                completion(info)
        }
    }
    
    static func getListProductCategory(userName: String?, password: String?, parentCategory: Int, completion: @escaping([ProductCategory]?) -> Void)
    {
        Alamofire.request(
            URL(string: "http://104.199.251.67:8888/MyCareWS/getListProductCategory")!,
            method: .get,
            parameters: ["userName": userName ?? "",
                         "password": password ?? "",
                         "parentCategory": parentCategory])
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                    completion(nil)
                    return
                }
                
                guard ((response.result.value as? [String: Any]) != nil) else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                    completion(nil)
                    return
                }
                
                let json = JSON(data: response.data!)
                
                if (json["errCode"].intValue != 0)
                {
                    Utils.showAlert(title: "", body: json["message"].stringValue)
                    completion(nil)
                    return
                }
                
                let productCategories = json["result"].flatMap({ (productCategory) -> ProductCategory? in
                    let category = productCategory.1
                    return ProductCategory(lastUpdate: category["lastUpdate"].stringValue, createDate: category["createDate"].stringValue, displayName: category["displayName"].stringValue, id: category["id"].stringValue, name: category["name"].stringValue, parentLeft: category["parentLeft"].stringValue, parentRight: category["parentRight"].stringValue, productCount: category["productCount"].stringValue, propertyCostMethod: category["propertyCostMethod"].stringValue, propertyValuation: category["propertyValuation"].stringValue, type: category["type"].stringValue, writeDate: category["writeDate"].stringValue)
                })
                completion(productCategories)
        }
    }
    
    static func getActiveProduct(userName: String?, password: String?, categoryId: Int, completion: @escaping([Product]?) -> Void)
    {
        Alamofire.request(
            URL(string: "http://104.199.251.67:8888/MyCareWS/getActiveProduct")!,
            method: .get,
            parameters: ["userName": userName ?? "",
                         "password": password ?? "",
                         "categoryId": categoryId])
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                    completion(nil)
                    return
                }
                
                guard ((response.result.value as? [String: Any]) != nil) else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                    completion(nil)
                    return
                }
                
                let json = JSON(data: response.data!)
                
                if (json["errCode"].intValue != 0)
                {
                    Utils.showAlert(title: "", body: json["message"].stringValue)
                    completion(nil)
                    return
                }
                
                let products = json["result"].flatMap({ (productJson) -> Product? in
                    let product = productJson.1
                    
                    return Product(categId: product["categId"].stringValue, displayName: product["displayName"].stringValue, id: product["id"].stringValue, image: product["image"].stringValue.replacingOccurrences(of: "\n", with: ""), listPrice: product["listPrice"].stringValue, lstPrice: product["lstPrice"].stringValue)
                })
                completion(products)
        }
    }
    
    static func getCurrentUserSaleOrder(userName: String?, password: String?, completion: @escaping([UserOrder]?) -> Void)
    {
        Alamofire.request(
            URL(string: "http://104.199.251.67:8888/MyCareWS/getCurrentUserSaleOrder")!,
            method: .get,
            parameters: ["userName": userName ?? "",
                         "password": password ?? ""])
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                    completion(nil)
                    return
                }
                
                guard ((response.result.value as? [String: Any]) != nil) else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                    completion(nil)
                    return
                }
                
                let json = JSON(data: response.data!)
                
                if (json["errCode"].intValue != 0)
                {
                    Utils.showAlert(title: "", body: json["message"].stringValue)
                    completion(nil)
                    return
                }
                
                let userOrders = json["result"].flatMap({ (userOrderJson) -> UserOrder? in
                    let userOrder = userOrderJson.1
                    
                    return UserOrder(id: userOrder["id"].stringValue, displayName: userOrder["displayName"].stringValue, dateOrder: userOrder["dateOrder"].stringValue, amountTotal: userOrder["amountTotal"].stringValue, amountTax: userOrder["amountTax"].stringValue, amountUntaxed: userOrder["amountUntaxed"].stringValue)
                })
                completion(userOrders)
        }
    }
    
    static func getSaleOrderDetailById(userName: String?, password: String?, saleOrderId: String?, completion: @escaping([UserOrder]?) -> Void)
    {
        Alamofire.request(
            URL(string: "http://104.199.251.67:8888/MyCareWS/getCurrentUserSaleOrder")!,
            method: .get,
            parameters: ["userName": userName ?? "",
                         "password": password ?? "",
                         "saleOrderId": saleOrderId ?? ""])
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                    completion(nil)
                    return
                }
                
                guard ((response.result.value as? [String: Any]) != nil) else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                    completion(nil)
                    return
                }
                
                let json = JSON(data: response.data!)
                
                if (json["errCode"].intValue != 0)
                {
                    Utils.showAlert(title: "", body: json["message"].stringValue)
                    completion(nil)
                    return
                }
                
                let userOrders = json["result"].flatMap({ (userOrderJson) -> UserOrder? in
                    let userOrder = userOrderJson.1
                    
                    return UserOrder(id: userOrder["id"].stringValue, displayName: userOrder["displayName"].stringValue, dateOrder: userOrder["dateOrder"].stringValue, amountTotal: userOrder["amountTotal"].stringValue, amountTax: userOrder["amountTax"].stringValue, amountUntaxed: userOrder["amountUntaxed"].stringValue)
                })
                completion(userOrders)
        }
    }
    
    static func getListInformation(userName: String?, password: String?, blogId: String?, completion: @escaping([News]?) -> Void)
    {
        Alamofire.request(
            URL(string: "http://104.199.251.67:8888/MyCareWS/getListInformation")!,
            method: .get,
            parameters: ["userName": userName ?? "",
                         "password": password ?? "",
                         "blogId": blogId ?? ""])
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.error))
                    completion(nil)
                    return
                }
                
                guard ((response.result.value as? [String: Any]) != nil) else
                {
                    Utils.showAlert(title: "Error!", body: String(describing: response.result.value))
                    completion(nil)
                    return
                }
                
                let json = JSON(data: response.data!)
                
                if (json["errCode"].intValue != 0)
                {
                    Utils.showAlert(title: "", body: json["message"].stringValue)
                    completion(nil)
                    return
                }
                
                let lstNews = json["result"].flatMap({ (newsJson) -> News? in
                    let news = newsJson.1
                    
                    return News(id: news["id"].stringValue, publishedDate: news["publishedDate"].stringValue, name: news["name"].stringValue, content: news["content"].stringValue, blogId: news["blogId"].stringValue, coverProperties: news["coverProperties"].stringValue)
                })
                completion(lstNews)
        }
    }
}
