//
//  MenuItem.swift
//  CareShop
//
//  Created by thinhhq1 on 10/23/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import Foundation

class MenuItem
{
    var id: Int?
    var title: String?
    var icon: UIImage?
    
    init(id: Int, title: String, icon: UIImage)
    {
        self.id = id
        self.title = title
        self.icon = icon
    }
}
