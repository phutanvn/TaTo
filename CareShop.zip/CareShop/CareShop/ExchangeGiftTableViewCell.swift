//
//  ExchangeGiftTableViewCell.swift
//  CareShop
//
//  Created by Cupid on 11/6/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit

class ExchangeGiftTableViewCell: UITableViewCell {

    @IBOutlet weak var imgGift: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var btnSubstract: UIButton!
    @IBOutlet weak var lblQuantity: UILabel!
    @IBOutlet weak var btnAddition: UIButton!
    @IBOutlet weak var btnExchange: UIButton!
        {
            didSet
            {
                btnExchange.layer.cornerRadius = btnExchange.frame.size.height/2
            }
        }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
