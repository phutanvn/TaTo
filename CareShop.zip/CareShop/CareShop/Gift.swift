//
//  Gift.swift
//  CareShop
//
//  Created by Cupid on 11/6/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit

struct Gift
{
    var name: String?
    var price: String?
    var image: UIImage?
    var quantity: Int
}
