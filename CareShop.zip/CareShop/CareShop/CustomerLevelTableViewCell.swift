//
//  CustomerLevelTableViewCell.swift
//  CareShop
//
//  Created by Vtsoft2 on 10/18/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit

class CustomerLevelTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
