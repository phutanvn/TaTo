//
//  MenuViewController.swift
//  CareShop
//
//  Created by Vtsoft2 on 10/17/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UITabBarControllerDelegate
{
    @IBOutlet weak var tblMenu: UITableView!
    
    var lstMenu = [MenuItem]()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        lstMenu.append(MenuItem(id: 1, title: "Thông tin khách hàng", icon: UIImage.init(named: "icon-MenuUser")!))
        lstMenu.append(MenuItem(id: 2, title: "Thông tin sản phẩm", icon: UIImage.init(named: "icon-MenuProduct")!))
        lstMenu.append(MenuItem(id: 3, title: "Thông tin khuyến mại", icon: UIImage.init(named: "icon-MenuPromotion")!))
        lstMenu.append(MenuItem(id: 4, title: "Thông tin tiêu dùng", icon: UIImage.init(named: "icon-MenuTransaction")!))
        lstMenu.append(MenuItem(id: 5, title: "Giới thiệu ShopCare", icon: UIImage.init(named: "icon-MenuUser")!))
        lstMenu.append(MenuItem(id: 6, title: "Đánh giá sản phẩm", icon: UIImage.init(named: "icon-MenuRate")!))
        lstMenu.append(MenuItem(id: 7, title: "Chia sẻ bạn bè", icon: UIImage.init(named: "icon-MenuShare")!))
        lstMenu.append(MenuItem(id: 8, title: "Đăng xuất", icon: UIImage.init(named: "icon-MenuLogout")!))
        
        let tabBarController = revealViewController().frontViewController as! UITabBarController
        tabBarController.delegate = self
        
        self.tblMenu.separatorColor = UIColor.lightGray
        self.tblMenu.dataSource = self
        self.tblMenu.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /* TanDP - TableViewDelegate */
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return lstMenu.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 60
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuTableViewCell", for: indexPath) as! MenuTableViewCell
        
        let menuItem = lstMenu[indexPath.row]
        
        cell.imgIcon.image = menuItem.icon
        cell.lblMenuTitle.text = menuItem.title
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        /*let productViewController = self.storyboard?.instantiateViewController(withIdentifier: "ProductViewController") as! ProductViewController
        self.revealViewController().pushFrontViewController(productViewController, animated: true)*/
        
        let tabBarController = revealViewController().frontViewController as! UITabBarController
        
        tabBarController.selectedIndex = 2
        revealViewController().pushFrontViewController(tabBarController,animated:true)
    }
    
    // MARK : TabBar Controller delegate
    
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        
        // Set the selection in menu table view when user tap on an item on tab bar
        let indexPath = IndexPath(row: tabBarController.selectedIndex, section: 0)
        self.tblMenu.selectRow(at: indexPath, animated: true, scrollPosition: UITableViewScrollPosition.none)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
