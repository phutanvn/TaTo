//
//  ChatViewController.swift
//  CareShop
//
//  Created by Cupid on 11/1/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit

class ChatViewController: UIViewController {

    @IBOutlet weak var webviewChat: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.webviewChat.loadRequest(URLRequest(url: URL(string: "http://104.199.251.67:8069/im_livechat/support/4")!))
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnCloseTouched(_ sender: Any)
    {
        self.dismiss(animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
