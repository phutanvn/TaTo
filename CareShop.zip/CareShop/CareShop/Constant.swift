//
//  Constant.swift
//  CareShop
//
//  Created by thinhhq1 on 10/23/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import Foundation

struct Constant
{
    static let webserviceUrl: String = "http://35.187.151.32:8888/MyCareWS/getUserInfo?userName=tienmh@gmail.com&password=12345678a@"
}
