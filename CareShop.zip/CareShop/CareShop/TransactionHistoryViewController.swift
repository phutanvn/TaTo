//
//  TransactionHistoryViewController.swift
//  CareShop
//
//  Created by thinhhq1 on 10/27/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit
import SwiftOverlays

class TransactionHistoryViewController: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    @IBOutlet weak var tblTransaction: UITableView!
    @IBOutlet weak var viewTop: UIView!
    
    var lstTransaction = [UserOrder]()
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.tblTransaction.dataSource = self
        self.tblTransaction.delegate = self
        
        self.getTransactionHistory()
    }

    func getTransactionHistory()
    {
        SwiftOverlays.showTextOverlay(self.tblTransaction, text: "Đang tải dữ liệu...")
        DataCenter.getCurrentUserSaleOrder(userName: Session.userInfo?.userName, password: Session.userInfo?.password, completion:
            {orders in
                
                if (orders != nil)
                {
                    self.lstTransaction = orders!
                    self.tblTransaction.reloadData()
                }
                SwiftOverlays.removeAllOverlaysFromView(self.tblTransaction)
        })
    }
    
    /* TanDP - TableViewDelegate */
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.lstTransaction.count + 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if (indexPath.row >= 0 && indexPath.row <= self.lstTransaction.count + 1)
        {
            return 45
        }
        else
        {
            return 1000
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
    {
        return 0.01
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if (indexPath.row == 0)
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "TransactionTableViewCell", for: indexPath) as! TransactionTableViewCell
            
            cell.lblOrderNumber.textColor = UIColor.white
            cell.lblOrderDate.textColor = UIColor.white
            cell.lblTotalAmount.textColor = UIColor.white
            cell.backgroundColor = self.viewTop.backgroundColor
            
            return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "TransactionTableViewCell", for: indexPath) as! TransactionTableViewCell
            let transaction = lstTransaction[indexPath.row-1]
            
            cell.lblOrderNumber.text = transaction.displayName
            cell.lblOrderDate.text = transaction.dateOrder
            cell.lblTotalAmount.text = transaction.amountTotal
            
            return cell
        }
    }
    
    @IBAction func btnCloseTouched(_ sender: Any)
    {
        self.dismiss(animated: true)        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
