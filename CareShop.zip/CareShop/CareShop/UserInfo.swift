//
//  UserInfo.swift
//  CareShop
//
//  Created by Cupid on 10/28/17.
//  Copyright © 2017 HFC. All rights reserved.
//

import UIKit

struct UserInfo
{
    var userName: String?
    var password: String?
    var displayName: String?
    var email: String?
    var id: Int
    var contactAddress: String?
    var imageSmall: String?
}
